#!/bin/bash
# Revert script for /mnt/c/Users/masha/Documents/claude-flow-novice/planning/docker-migration/DEPENDENCY_DIAGRAM.txt
set -euo pipefail

echo "Reverting file: /mnt/c/Users/masha/Documents/claude-flow-novice/planning/docker-migration/DEPENDENCY_DIAGRAM.txt"
cp "/mnt/c/Users/masha/Documents/claude-flow-novice/.claude/skills/cfn-loop-orchestration/.backups/unknown/1763671642_06496e8c399a79db08167cc00ed4b31e/original" "/mnt/c/Users/masha/Documents/claude-flow-novice/planning/docker-migration/DEPENDENCY_DIAGRAM.txt"
echo "✅ File reverted successfully"
