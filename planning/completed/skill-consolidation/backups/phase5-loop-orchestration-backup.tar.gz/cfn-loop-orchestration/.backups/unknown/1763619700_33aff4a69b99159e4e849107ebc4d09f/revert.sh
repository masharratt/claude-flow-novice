#!/bin/bash
# Revert script for /mnt/c/Users/masha/Documents/claude-flow-novice/.claude/agents/cfn-dev-team/coordinators/cfn-v3-coordinator.md
set -euo pipefail

echo "Reverting file: /mnt/c/Users/masha/Documents/claude-flow-novice/.claude/agents/cfn-dev-team/coordinators/cfn-v3-coordinator.md"
cp "/mnt/c/Users/masha/Documents/claude-flow-novice/.claude/skills/cfn-loop-orchestration/.backups/unknown/1763619700_33aff4a69b99159e4e849107ebc4d09f/original" "/mnt/c/Users/masha/Documents/claude-flow-novice/.claude/agents/cfn-dev-team/coordinators/cfn-v3-coordinator.md"
echo "✅ File reverted successfully"
