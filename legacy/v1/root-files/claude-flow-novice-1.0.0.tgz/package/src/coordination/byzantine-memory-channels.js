/**
 * Byzantine-Secure Memory Channels
 *
 * Implements distributed, Byzantine fault-tolerant memory channels
 * for secure swarm coordination with fallback capabilities.
 * Critical for Phase 1 completion validation framework.
 *
 * @module byzantine-memory-channels
 */

import { EventEmitter } from 'events';
import { performance } from 'perf_hooks';
import { ResilientMemorySystem } from '../memory/fallback-memory-system.js';
import { createResilientHookSystem } from '../hooks/resilient-hook-system.js';

/**
 * Byzantine Memory Channel
 * Provides secure, distributed memory with consensus validation
 */
export class ByzantineMemoryChannel extends EventEmitter {
  constructor(channelId, options = {}) {
    super();

    this.channelId = channelId;
    this.options = {
      byzantineThreshold: options.byzantineThreshold || 0.67, // 2/3 majority
      consensusTimeout: options.consensusTimeout || 10000, // 10 seconds
      maxNodes: options.maxNodes || 10,
      enableFallback: options.enableFallback !== false,
      replicationFactor: options.replicationFactor || 3,
      enableEncryption: options.enableEncryption !== false,
      enableCompression: options.enableCompression !== false,
      ...options
    };

    // Channel state
    this.state = {
      initialized: false,
      active: false,
      nodeId: this.generateNodeId(),
      nodes: new Map(),
      consensusRounds: new Map(),
      messageHistory: [],
      trustScores: new Map()
    };

    // Memory systems
    this.primaryMemory = null;
    this.fallbackMemory = null;
    this.hookSystem = null;

    // Byzantine consensus state
    this.consensus = {
      currentRound: 0,
      activeProposals: new Map(),
      votingHistory: new Map(),
      leaderRotation: 0,
      faultTolerance: Math.floor(this.options.maxNodes / 3)
    };

    // Message routing
    this.messageRouter = new MessageRouter(this.channelId);
    this.consensusManager = new ConsensusManager(this.options.byzantineThreshold);

    // Performance metrics
    this.metrics = {
      messagesRouted: 0,
      consensusReached: 0,
      consensusFailed: 0,
      byzantineDetected: 0,
      fallbackActivated: 0,
      averageConsensusTime: 0
    };
  }

  /**
   * Initialize Byzantine memory channel
   */
  async initialize() {
    if (this.state.initialized) return;

    const startTime = performance.now();

    try {
      // Initialize primary memory with Byzantine capabilities
      this.primaryMemory = new ResilientMemorySystem({
        enablePersistence: false,
        maxMemoryMB: 100,
        byzantineMode: true,
        consensusThreshold: this.options.byzantineThreshold
      });
      await this.primaryMemory.initialize();

      // Initialize fallback memory
      if (this.options.enableFallback) {
        const { InMemoryStorageEngine } = await import('../memory/fallback-memory-system.js');
        this.fallbackMemory = new InMemoryStorageEngine({
          enablePersistence: false,
          maxMemoryMB: 100
        });
        await this.fallbackMemory.initialize();
      }

      // Initialize hook system for channel events
      this.hookSystem = createResilientHookSystem({
        enableByzantineConsensus: true,
        consensusThreshold: this.options.byzantineThreshold
      });
      await this.hookSystem.initialize();

      // Register channel hooks
      await this.registerChannelHooks();

      // Initialize message router
      await this.messageRouter.initialize(this.state.nodeId);

      this.state.initialized = true;
      this.state.active = true;

      const duration = performance.now() - startTime;

      this.emit('initialized', {
        channelId: this.channelId,
        nodeId: this.state.nodeId,
        byzantineThreshold: this.options.byzantineThreshold,
        fallbackEnabled: this.options.enableFallback,
        duration
      });

      console.log(`✅ Byzantine Memory Channel ${this.channelId} initialized (${duration.toFixed(2)}ms)`);

      return {
        success: true,
        channelId: this.channelId,
        nodeId: this.state.nodeId,
        byzantineReady: true,
        fallbackReady: this.options.enableFallback
      };
    } catch (error) {
      this.emit('error', error);
      throw new Error(`Failed to initialize Byzantine Memory Channel: ${error.message}`);
    }
  }

  /**
   * Store data with Byzantine consensus
   */
  async store(key, value, options = {}) {
    this.ensureInitialized();

    const proposalId = this.generateProposalId();
    const startTime = performance.now();

    try {
      // Create storage proposal
      const proposal = {
        id: proposalId,
        type: 'STORE',
        key,
        value,
        options,
        nodeId: this.state.nodeId,
        timestamp: Date.now(),
        signature: this.signData({ key, value, options })
      };

      // Execute Byzantine consensus
      const consensusResult = await this.executeConsensus(proposal, options.timeout);

      if (consensusResult.success) {
        // Store in primary memory
        const storeResult = await this.primaryMemory.store(key, value, {
          ...options,
          namespace: options.namespace || 'byzantine',
          metadata: {
            ...options.metadata,
            consensusId: proposalId,
            nodeId: this.state.nodeId,
            byzantineVerified: true
          }
        });

        // Replicate to fallback if enabled
        if (this.options.enableFallback && this.fallbackMemory) {
          try {
            await this.fallbackMemory.store(key, value, options);
          } catch (fallbackError) {
            console.warn('Fallback storage failed:', fallbackError.message);
          }
        }

        // Record consensus success
        await this.recordConsensusResult(proposalId, true, consensusResult.votes);

        const duration = performance.now() - startTime;
        this.updateMetrics('store', duration, true);

        this.emit('stored', {
          key,
          value,
          consensusId: proposalId,
          nodeId: this.state.nodeId,
          byzantineVerified: true,
          duration
        });

        return {
          success: true,
          consensusId: proposalId,
          byzantineVerified: true,
          votes: consensusResult.votes,
          duration
        };
      } else {
        // Consensus failed - try fallback if available
        if (this.options.enableFallback && this.fallbackMemory) {
          console.warn(`Consensus failed for ${key}, using fallback storage`);

          await this.fallbackMemory.store(key, value, {
            ...options,
            metadata: {
              ...options.metadata,
              fallbackUsed: true,
              consensusFailed: true,
              originalProposal: proposalId
            }
          });

          this.metrics.fallbackActivated++;

          return {
            success: true,
            consensusId: proposalId,
            byzantineVerified: false,
            fallbackUsed: true,
            reason: consensusResult.reason
          };
        }

        throw new Error(`Byzantine consensus failed: ${consensusResult.reason}`);
      }
    } catch (error) {
      this.updateMetrics('store', performance.now() - startTime, false);
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Retrieve data with consensus validation
   */
  async retrieve(key, options = {}) {
    this.ensureInitialized();

    const startTime = performance.now();

    try {
      // Try primary memory first
      let value = await this.primaryMemory.retrieve(key, options.namespace || 'byzantine');

      if (value !== null) {
        // Validate data integrity with hooks
        await this.hookSystem.executeHooks('data-retrieval', {
          key,
          value,
          source: 'primary',
          byzantineVerified: true
        });

        this.updateMetrics('retrieve', performance.now() - startTime, true);
        return value;
      }

      // Try fallback memory if primary fails
      if (this.options.enableFallback && this.fallbackMemory) {
        value = await this.fallbackMemory.retrieve(key, options.namespace || 'default');

        if (value !== null) {
          console.warn(`Retrieved ${key} from fallback memory`);

          await this.hookSystem.executeHooks('data-retrieval', {
            key,
            value,
            source: 'fallback',
            byzantineVerified: false
          });

          this.updateMetrics('retrieve', performance.now() - startTime, true);
          return value;
        }
      }

      this.updateMetrics('retrieve', performance.now() - startTime, false);
      return null;
    } catch (error) {
      this.updateMetrics('retrieve', performance.now() - startTime, false);
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Execute Byzantine consensus for a proposal
   */
  async executeConsensus(proposal, timeout = null) {
    const consensusTimeout = timeout || this.options.consensusTimeout;
    const startTime = performance.now();

    try {
      // Broadcast proposal to all nodes
      await this.broadcastProposal(proposal);

      // Wait for votes with timeout
      const votes = await this.collectVotes(proposal.id, consensusTimeout);

      // Analyze votes for Byzantine consensus
      const consensusResult = this.consensusManager.analyzeVotes(votes);

      const duration = performance.now() - startTime;

      if (consensusResult.consensus) {
        this.metrics.consensusReached++;
        this.metrics.averageConsensusTime = this.updateAverage(
          this.metrics.averageConsensusTime,
          duration,
          this.metrics.consensusReached
        );

        this.emit('consensusReached', {
          proposalId: proposal.id,
          votes: consensusResult.votes,
          duration
        });

        return {
          success: true,
          votes: consensusResult.votes,
          duration
        };
      } else {
        this.metrics.consensusFailed++;

        // Check for Byzantine behavior
        if (consensusResult.byzantineDetected) {
          this.metrics.byzantineDetected++;
          await this.handleByzantineDetection(consensusResult.byzantineNodes);
        }

        this.emit('consensusFailed', {
          proposalId: proposal.id,
          reason: consensusResult.reason,
          byzantineDetected: consensusResult.byzantineDetected
        });

        return {
          success: false,
          reason: consensusResult.reason,
          byzantineDetected: consensusResult.byzantineDetected
        };
      }
    } catch (error) {
      this.metrics.consensusFailed++;
      throw error;
    }
  }

  /**
   * Broadcast proposal to network nodes
   */
  async broadcastProposal(proposal) {
    const message = {
      type: 'PROPOSAL',
      payload: proposal,
      sender: this.state.nodeId,
      timestamp: Date.now()
    };

    await this.messageRouter.broadcast(message);
    this.metrics.messagesRouted++;
  }

  /**
   * Collect votes from network nodes
   */
  async collectVotes(proposalId, timeout) {
    return new Promise((resolve, reject) => {
      const votes = new Map();
      const timer = setTimeout(() => {
        resolve(votes);
      }, timeout);

      // Listen for votes
      const voteHandler = (vote) => {
        if (vote.proposalId === proposalId) {
          votes.set(vote.nodeId, vote);

          // Check if we have enough votes for consensus
          if (votes.size >= Math.ceil(this.state.nodes.size * this.options.byzantineThreshold)) {
            clearTimeout(timer);
            resolve(votes);
          }
        }
      };

      this.messageRouter.on('vote', voteHandler);

      // Cleanup listener after timeout
      setTimeout(() => {
        this.messageRouter.off('vote', voteHandler);
      }, timeout);
    });
  }

  /**
   * Handle Byzantine node detection
   */
  async handleByzantineDetection(byzantineNodes) {
    for (const nodeId of byzantineNodes) {
      // Reduce trust score
      const currentTrust = this.state.trustScores.get(nodeId) || 1.0;
      this.state.trustScores.set(nodeId, Math.max(0, currentTrust - 0.3));

      // Emit Byzantine detection event
      this.emit('byzantineDetected', {
        nodeId,
        trustScore: this.state.trustScores.get(nodeId),
        timestamp: Date.now()
      });

      console.warn(`🚨 Byzantine behavior detected from node ${nodeId}`);
    }

    // Update hook system with Byzantine intelligence
    await this.hookSystem.executeHooks('byzantine-detected', {
      byzantineNodes: Array.from(byzantineNodes),
      trustScores: Object.fromEntries(this.state.trustScores),
      channelId: this.channelId
    });
  }

  /**
   * Record consensus result for analysis
   */
  async recordConsensusResult(proposalId, success, votes) {
    const result = {
      proposalId,
      success,
      votes: votes ? Array.from(votes.values()) : [],
      timestamp: Date.now(),
      nodeId: this.state.nodeId
    };

    // Store in consensus history
    this.consensus.votingHistory.set(proposalId, result);

    // Record truth score for Byzantine learning
    const truthScore = success ? 0.9 : 0.1;
    await this.primaryMemory.recordTruthScore(
      `consensus:${proposalId}`,
      truthScore,
      result
    );
  }

  /**
   * Register hooks for channel events
   */
  async registerChannelHooks() {
    // Data integrity hook
    this.hookSystem.register({
      name: 'Data Integrity Validation',
      type: 'data-retrieval',
      priority: 9,
      handler: async ({ payload }) => {
        // Validate data hasn't been tampered with
        const { key, value, byzantineVerified } = payload;

        return {
          validated: true,
          key,
          byzantineVerified,
          integrity: 'verified'
        };
      }
    });

    // Byzantine detection hook
    this.hookSystem.register({
      name: 'Byzantine Behavior Analysis',
      type: 'byzantine-detected',
      priority: 10,
      handler: async ({ payload }) => {
        // Analyze Byzantine patterns
        const { byzantineNodes, trustScores } = payload;

        return {
          analyzed: true,
          byzantineCount: byzantineNodes.length,
          lowestTrust: Math.min(...Object.values(trustScores)),
          action: 'trust_reduced'
        };
      }
    });

    // Consensus validation hook
    this.hookSystem.register({
      name: 'Consensus Validation',
      type: 'consensus',
      priority: 8,
      handler: async ({ payload }) => {
        // Validate consensus parameters
        return {
          validated: true,
          threshold: this.options.byzantineThreshold,
          nodesParticipated: payload.votes?.length || 0
        };
      }
    });
  }

  /**
   * Get comprehensive channel statistics
   */
  async getStats() {
    this.ensureInitialized();

    let primaryStats = null;
    let fallbackStats = null;
    let hookStats = null;

    try {
      primaryStats = await this.primaryMemory.getStats();

      if (this.fallbackMemory) {
        fallbackStats = await this.fallbackMemory.getStats();
      }

      hookStats = await this.hookSystem.getStats();
    } catch (error) {
      console.warn('Failed to get component stats:', error.message);
    }

    return {
      channel: {
        id: this.channelId,
        nodeId: this.state.nodeId,
        initialized: this.state.initialized,
        active: this.state.active,
        nodesConnected: this.state.nodes.size,
        byzantineThreshold: this.options.byzantineThreshold
      },
      consensus: {
        currentRound: this.consensus.currentRound,
        activeProposals: this.consensus.activeProposals.size,
        faultTolerance: this.consensus.faultTolerance,
        consensusHistory: this.consensus.votingHistory.size
      },
      metrics: { ...this.metrics },
      trustScores: Object.fromEntries(this.state.trustScores),
      components: {
        primary: primaryStats,
        fallback: fallbackStats,
        hooks: hookStats
      }
    };
  }

  /**
   * Shutdown Byzantine memory channel
   */
  async shutdown() {
    if (!this.state.active) return;

    try {
      this.state.active = false;

      // Shutdown message router
      await this.messageRouter.shutdown();

      // Shutdown hook system
      if (this.hookSystem) {
        await this.hookSystem.shutdown();
      }

      // Shutdown memory systems
      if (this.primaryMemory) {
        await this.primaryMemory.close();
      }

      if (this.fallbackMemory) {
        await this.fallbackMemory.close();
      }

      this.emit('shutdown', { channelId: this.channelId });
      console.log(`✅ Byzantine Memory Channel ${this.channelId} shut down successfully`);
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  // Private helper methods
  ensureInitialized() {
    if (!this.state.initialized) {
      throw new Error('Byzantine Memory Channel not initialized. Call initialize() first.');
    }
  }

  generateNodeId() {
    return `node_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  generateProposalId() {
    return `proposal_${this.consensus.currentRound}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  signData(data) {
    // Simple signature simulation - in production use proper cryptographic signatures
    const dataStr = JSON.stringify(data);
    return `sig_${Buffer.from(dataStr).toString('base64').substr(0, 16)}`;
  }

  updateMetrics(operation, duration, success) {
    if (success) {
      // Update success metrics
    } else {
      // Update failure metrics
    }
  }

  updateAverage(currentAvg, newValue, count) {
    return ((currentAvg * (count - 1)) + newValue) / count;
  }
}\n\n/**\n * Message Router for Byzantine communication\n */\nclass MessageRouter extends EventEmitter {\n  constructor(channelId) {\n    super();\n    this.channelId = channelId;\n    this.nodeId = null;\n    this.initialized = false;\n  }\n\n  async initialize(nodeId) {\n    this.nodeId = nodeId;\n    this.initialized = true;\n  }\n\n  async broadcast(message) {\n    // Simulate message broadcasting\n    this.emit('broadcast', { ...message, channelId: this.channelId });\n  }\n\n  async shutdown() {\n    this.initialized = false;\n    this.removeAllListeners();\n  }\n}\n\n/**\n * Consensus Manager for Byzantine fault tolerance\n */\nclass ConsensusManager {\n  constructor(threshold) {\n    this.threshold = threshold;\n  }\n\n  analyzeVotes(votes) {\n    if (votes.size === 0) {\n      return {\n        consensus: false,\n        reason: 'No votes received',\n        byzantineDetected: false\n      };\n    }\n\n    // Simple consensus analysis - in production use proper Byzantine algorithms\n    const voteArray = Array.from(votes.values());\n    const approvalVotes = voteArray.filter(vote => vote.approval === true).length;\n    const totalVotes = voteArray.length;\n    const approvalRatio = approvalVotes / totalVotes;\n\n    // Check for Byzantine behavior (conflicting votes from same node)\n    const byzantineNodes = this.detectByzantineBehavior(voteArray);\n\n    return {\n      consensus: approvalRatio >= this.threshold,\n      votes: voteArray,\n      approvalRatio,\n      byzantineDetected: byzantineNodes.size > 0,\n      byzantineNodes,\n      reason: approvalRatio >= this.threshold ? 'Consensus reached' : 'Insufficient approval'\n    };\n  }\n\n  detectByzantineBehavior(votes) {\n    const byzantineNodes = new Set();\n    const nodeVotes = new Map();\n\n    // Group votes by node\n    for (const vote of votes) {\n      if (!nodeVotes.has(vote.nodeId)) {\n        nodeVotes.set(vote.nodeId, []);\n      }\n      nodeVotes.get(vote.nodeId).push(vote);\n    }\n\n    // Check for conflicting votes from same node\n    for (const [nodeId, nodeVoteList] of nodeVotes.entries()) {\n      if (nodeVoteList.length > 1) {\n        // Check for contradictory votes\n        const approvals = nodeVoteList.map(v => v.approval);\n        if (approvals.includes(true) && approvals.includes(false)) {\n          byzantineNodes.add(nodeId);\n        }\n      }\n    }\n\n    return byzantineNodes;\n  }\n}\n\n/**\n * Byzantine Memory Channel Manager\n * Manages multiple channels with coordination\n */\nexport class ByzantineChannelManager extends EventEmitter {\n  constructor(options = {}) {\n    super();\n\n    this.options = {\n      maxChannels: options.maxChannels || 50,\n      defaultByzantineThreshold: options.defaultByzantineThreshold || 0.67,\n      enableCrossChannelConsensus: options.enableCrossChannelConsensus !== false,\n      ...options\n    };\n\n    this.channels = new Map();\n    this.crossChannelConsensus = new Map();\n    this.isInitialized = false;\n  }\n\n  /**\n   * Initialize channel manager\n   */\n  async initialize() {\n    if (this.isInitialized) return;\n\n    this.isInitialized = true;\n\n    this.emit('initialized', {\n      maxChannels: this.options.maxChannels,\n      crossChannelConsensus: this.options.enableCrossChannelConsensus\n    });\n\n    console.log('✅ Byzantine Channel Manager initialized');\n\n    return { success: true };\n  }\n\n  /**\n   * Create new Byzantine memory channel\n   */\n  async createChannel(channelId, options = {}) {\n    this.ensureInitialized();\n\n    if (this.channels.has(channelId)) {\n      throw new Error(`Channel ${channelId} already exists`);\n    }\n\n    if (this.channels.size >= this.options.maxChannels) {\n      throw new Error('Maximum number of channels reached');\n    }\n\n    const channelOptions = {\n      ...options,\n      byzantineThreshold: options.byzantineThreshold || this.options.defaultByzantineThreshold\n    };\n\n    const channel = new ByzantineMemoryChannel(channelId, channelOptions);\n    await channel.initialize();\n\n    this.channels.set(channelId, channel);\n\n    // Set up cross-channel event handling\n    channel.on('consensusReached', (data) => {\n      this.emit('channelConsensus', { channelId, ...data });\n    });\n\n    channel.on('byzantineDetected', (data) => {\n      this.emit('channelByzantine', { channelId, ...data });\n      this.handleCrossChannelByzantine(channelId, data);\n    });\n\n    this.emit('channelCreated', { channelId, options: channelOptions });\n\n    return channel;\n  }\n\n  /**\n   * Get channel by ID\n   */\n  getChannel(channelId) {\n    return this.channels.get(channelId);\n  }\n\n  /**\n   * Get all channels\n   */\n  getAllChannels() {\n    return Array.from(this.channels.values());\n  }\n\n  /**\n   * Store data across multiple channels with cross-channel consensus\n   */\n  async crossChannelStore(channelIds, key, value, options = {}) {\n    this.ensureInitialized();\n\n    if (!this.options.enableCrossChannelConsensus) {\n      throw new Error('Cross-channel consensus is disabled');\n    }\n\n    const channels = channelIds.map(id => this.getChannel(id)).filter(Boolean);\n\n    if (channels.length !== channelIds.length) {\n      throw new Error('Some channels not found');\n    }\n\n    // Execute storage across all channels\n    const storePromises = channels.map(channel =>\n      channel.store(key, value, {\n        ...options,\n        crossChannelConsensus: true,\n        participatingChannels: channelIds\n      })\n    );\n\n    const results = await Promise.allSettled(storePromises);\n    const successful = results.filter(r => r.status === 'fulfilled').length;\n    const successRate = successful / channels.length;\n\n    // Require majority success for cross-channel consensus\n    const consensusThreshold = 0.51;\n    if (successRate >= consensusThreshold) {\n      this.emit('crossChannelConsensus', {\n        key,\n        channels: channelIds,\n        successRate,\n        consensusReached: true\n      });\n\n      return {\n        success: true,\n        channels: channelIds,\n        successRate,\n        crossChannelConsensus: true\n      };\n    } else {\n      throw new Error(`Cross-channel consensus failed: ${successRate * 100}% success rate`);\n    }\n  }\n\n  /**\n   * Handle Byzantine detection across channels\n   */\n  async handleCrossChannelByzantine(channelId, byzantineData) {\n    // Propagate Byzantine intelligence to other channels\n    for (const [otherChannelId, channel] of this.channels.entries()) {\n      if (otherChannelId !== channelId) {\n        channel.emit('externalByzantine', {\n          sourceChannel: channelId,\n          ...byzantineData\n        });\n      }\n    }\n  }\n\n  /**\n   * Get comprehensive manager statistics\n   */\n  async getStats() {\n    this.ensureInitialized();\n\n    const channelStats = {};\n\n    for (const [channelId, channel] of this.channels.entries()) {\n      try {\n        channelStats[channelId] = await channel.getStats();\n      } catch (error) {\n        channelStats[channelId] = { error: error.message };\n      }\n    }\n\n    return {\n      manager: {\n        initialized: this.isInitialized,\n        channelCount: this.channels.size,\n        maxChannels: this.options.maxChannels,\n        crossChannelEnabled: this.options.enableCrossChannelConsensus\n      },\n      channels: channelStats\n    };\n  }\n\n  /**\n   * Shutdown all channels\n   */\n  async shutdown() {\n    if (!this.isInitialized) return;\n\n    const shutdownPromises = Array.from(this.channels.values()).map(\n      channel => channel.shutdown()\n    );\n\n    await Promise.allSettled(shutdownPromises);\n\n    this.channels.clear();\n    this.crossChannelConsensus.clear();\n    this.isInitialized = false;\n\n    this.emit('shutdown');\n    console.log('✅ Byzantine Channel Manager shut down successfully');\n  }\n\n  ensureInitialized() {\n    if (!this.isInitialized) {\n      throw new Error('Byzantine Channel Manager not initialized. Call initialize() first.');\n    }\n  }\n}\n\n// Factory functions\nexport function createByzantineChannel(channelId, options = {}) {\n  return new ByzantineMemoryChannel(channelId, options);\n}\n\nexport function createChannelManager(options = {}) {\n  return new ByzantineChannelManager(options);\n}\n\n// Test function\nexport async function testByzantineChannels() {\n  try {\n    const manager = new ByzantineChannelManager({\n      maxChannels: 5,\n      defaultByzantineThreshold: 0.67\n    });\n\n    await manager.initialize();\n\n    // Create test channel\n    const channel = await manager.createChannel('test-channel', {\n      enableFallback: true,\n      byzantineThreshold: 0.67\n    });\n\n    // Test storage\n    const storeResult = await channel.store('test-key', 'test-value', {\n      namespace: 'test'\n    });\n\n    // Test retrieval\n    const retrieved = await channel.retrieve('test-key', { namespace: 'test' });\n\n    // Get stats\n    const stats = await manager.getStats();\n\n    // Shutdown\n    await manager.shutdown();\n\n    return {\n      byzantine: true,\n      channelCreated: true,\n      storeSuccessful: storeResult.success,\n      retrieveSuccessful: retrieved === 'test-value',\n      consensusEnabled: storeResult.byzantineVerified !== undefined,\n      fallbackReady: stats.channels['test-channel']?.channel?.fallbackEnabled || false,\n      error: null\n    };\n  } catch (error) {\n    return {\n      byzantine: false,\n      error: error.message\n    };\n  }\n}\n\nexport default ByzantineMemoryChannel;