/**
 * IterationTracker - CFN Loop Iteration Counter and Limit Enforcement
 *
 * Tracks Loop 2 (phase-level) and Loop 3 (swarm-level) iterations with persistence
 * to SwarmMemory. Enforces maximum iteration limits and provides escalation triggers.
 *
 * @module coordination/iteration-tracker
 */

import { createSwarmMemory } from '../memory/swarm-memory.js';

/**
 * Iteration limits for CFN loops
 */
const ITERATION_LIMITS = {
  LOOP2_MAX: 5,   // Maximum phase-level iterations
  LOOP3_MAX: 10,  // Maximum swarm-level iterations
};

/**
 * Escalation strategies
 */
const ESCALATION_STRATEGIES = {
  LOOP2_EXCEEDED: 'phase_retry_limit',
  LOOP3_EXCEEDED: 'swarm_stuck',
  CONTINUE: 'continue',
};

/**
 * IterationTracker class
 * Manages iteration counting, limit enforcement, and state persistence
 */
export class IterationTracker {
  /**
   * Create an IterationTracker instance
   * @param {Object} options - Configuration options
   * @param {string} options.phaseId - Unique identifier for the current phase
   * @param {string} options.swarmId - Swarm identifier for memory namespace
   * @param {number} options.loop2Max - Custom Loop 2 max (default: 5)
   * @param {number} options.loop3Max - Custom Loop 3 max (default: 10)
   * @param {Object} options.memory - Optional SwarmMemory instance
   */
  constructor(options = {}) {
    this.phaseId = options.phaseId || `phase-${Date.now()}`;
    this.swarmId = options.swarmId || 'default';

    // Iteration limits with input validation
    // Use nullish coalescing to properly handle 0 value
    const loop2Max =
      options.loop2Max !== undefined
        ? options.loop2Max
        : ITERATION_LIMITS.LOOP2_MAX;
    const loop3Max =
      options.loop3Max !== undefined
        ? options.loop3Max
        : ITERATION_LIMITS.LOOP3_MAX;

    // SECURITY: Validate iteration limits (CVE-2025-001 fix)
    // Prevent DoS attacks via excessive iteration limits
    if (!Number.isInteger(loop2Max) || loop2Max < 1 || loop2Max > 100) {
      throw new Error(
        `Invalid loop2Max: ${loop2Max}. Must be integer between 1 and 100`
      );
    }
    if (!Number.isInteger(loop3Max) || loop3Max < 1 || loop3Max > 100) {
      throw new Error(
        `Invalid loop3Max: ${loop3Max}. Must be integer between 1 and 100`
      );
    }

    this.loop2Max = loop2Max;
    this.loop3Max = loop3Max;

    // Current iteration counters
    this.loop2Counter = 0; // Phase-level iterations
    this.loop3Counter = 0; // Swarm-level iterations

    // State tracking
    this.initialized = false;
    this.lastUpdated = null;
    this.escalationHistory = [];

    // Memory persistence
    this.memory = options.memory || null;
    this.memoryNamespace = `cfn-loop/iterations/${this.phaseId}`;

    // Statistics
    this.stats = {
      totalLoop2Iterations: 0,
      totalLoop3Iterations: 0,
      loop3Resets: 0,
      escalations: 0,
      successfulGatePasses: 0,
    };
  }

  /**
   * Initialize the tracker and load persisted state if available
   * @returns {Promise<Object>} Initialization result
   */
  async initialize() {
    if (this.initialized) {
      return { success: true, message: 'Already initialized' };
    }

    // Initialize SwarmMemory if not provided
    if (!this.memory) {
      this.memory = createSwarmMemory({ swarmId: this.swarmId });
      await this.memory.initialize();
    }

    // Try to load persisted state
    const loaded = await this.loadState(this.phaseId);

    if (loaded) {
      this.initialized = true;
      return {
        success: true,
        message: 'Loaded from persisted state',
        state: this.getState(),
      };
    }

    // Initialize fresh state
    this.initialized = true;
    this.lastUpdated = new Date().toISOString();

    // Persist initial state
    await this.persistState();

    return {
      success: true,
      message: 'Initialized fresh state',
      state: this.getState(),
    };
  }

  /**
   * Increment Loop 2 counter (phase-level iterations)
   * @returns {Promise<Object>} Result with current count and status
   */
  async incrementLoop2() {
    if (!this.initialized) {
      await this.initialize();
    }

    this.loop2Counter++;
    this.stats.totalLoop2Iterations++;
    this.lastUpdated = new Date().toISOString();

    const status = this.checkLimits();

    // Persist updated state
    await this.persistState();

    return {
      counter: this.loop2Counter,
      max: this.loop2Max,
      remaining: this.loop2Max - this.loop2Counter,
      status: status.status,
      escalate: status.escalate,
      message: `Loop 2 iteration ${this.loop2Counter}/${this.loop2Max}`,
    };
  }

  /**
   * Increment Loop 3 counter (swarm-level iterations)
   * @returns {Promise<Object>} Result with current count and status
   */
  async incrementLoop3() {
    if (!this.initialized) {
      await this.initialize();
    }

    this.loop3Counter++;
    this.stats.totalLoop3Iterations++;
    this.lastUpdated = new Date().toISOString();

    const status = this.checkLimits();

    // Persist updated state
    await this.persistState();

    return {
      counter: this.loop3Counter,
      max: this.loop3Max,
      remaining: this.loop3Max - this.loop3Counter,
      status: status.status,
      escalate: status.escalate,
      message: `Loop 3 iteration ${this.loop3Counter}/${this.loop3Max}`,
    };
  }

  /**
   * Check iteration limits and return status
   * @returns {Object} Status object with escalation flags
   */
  checkLimits() {
    // Check Loop 2 limit
    if (this.loop2Counter >= this.loop2Max) {
      return {
        status: ESCALATION_STRATEGIES.LOOP2_EXCEEDED,
        escalate: true,
        reason: 'Phase exceeded retry limit, escalating with feedback',
        loop: 2,
        counter: this.loop2Counter,
        max: this.loop2Max,
      };
    }

    // Check Loop 3 limit
    if (this.loop3Counter >= this.loop3Max) {
      return {
        status: ESCALATION_STRATEGIES.LOOP3_EXCEEDED,
        escalate: true,
        reason: 'Swarm stuck, resetting and trying new approach',
        loop: 3,
        counter: this.loop3Counter,
        max: this.loop3Max,
      };
    }

    // Within limits
    return {
      status: ESCALATION_STRATEGIES.CONTINUE,
      escalate: false,
      reason: 'Within iteration limits',
      loop2: {
        counter: this.loop2Counter,
        max: this.loop2Max,
        remaining: this.loop2Max - this.loop2Counter,
      },
      loop3: {
        counter: this.loop3Counter,
        max: this.loop3Max,
        remaining: this.loop3Max - this.loop3Counter,
      },
    };
  }

  /**
   * Reset Loop 3 counter (called on gate pass or phase completion)
   * @param {string} reason - Reason for reset
   * @returns {Promise<Object>} Reset confirmation
   */
  async resetLoop3(reason = 'gate_pass') {
    if (!this.initialized) {
      await this.initialize();
    }

    const previousCounter = this.loop3Counter;
    this.loop3Counter = 0;
    this.stats.loop3Resets++;

    if (reason === 'gate_pass') {
      this.stats.successfulGatePasses++;
    }

    this.lastUpdated = new Date().toISOString();

    // Persist updated state
    await this.persistState();

    return {
      success: true,
      previousCounter,
      currentCounter: 0,
      reason,
      message: `Loop 3 reset from ${previousCounter} to 0 (${reason})`,
    };
  }

  /**
   * Get current iteration state
   * @returns {Object} Current state snapshot
   */
  getState() {
    return {
      phaseId: this.phaseId,
      swarmId: this.swarmId,
      counters: {
        loop2: this.loop2Counter,
        loop3: this.loop3Counter,
      },
      limits: {
        loop2Max: this.loop2Max,
        loop3Max: this.loop3Max,
      },
      remaining: {
        loop2: this.loop2Max - this.loop2Counter,
        loop3: this.loop3Max - this.loop3Counter,
      },
      status: this.checkLimits(),
      stats: { ...this.stats },
      lastUpdated: this.lastUpdated,
      initialized: this.initialized,
    };
  }

  /**
   * Persist state to SwarmMemory
   * @returns {Promise<Object>} Persistence result
   */
  async persistState() {
    if (!this.memory) {
      throw new Error('Memory not initialized');
    }

    const state = this.getState();
    const key = `iteration-tracker:${this.phaseId}`;

    await this.memory.storeCoordination(key, {
      ...state,
      persistedAt: new Date().toISOString(),
    });

    return {
      success: true,
      key,
      namespace: this.memoryNamespace,
      state,
    };
  }

  /**
   * Load state from SwarmMemory
   * @param {string} phaseId - Phase ID to load state for
   * @returns {Promise<boolean>} True if state was loaded, false otherwise
   */
  async loadState(phaseId) {
    if (!this.memory) {
      return false;
    }

    const key = `iteration-tracker:${phaseId}`;

    try {
      const persistedState = await this.memory.getCoordination(key);

      if (!persistedState) {
        return false;
      }

      // Restore state
      this.phaseId = persistedState.phaseId;
      this.swarmId = persistedState.swarmId;
      this.loop2Counter = persistedState.counters.loop2;
      this.loop3Counter = persistedState.counters.loop3;
      this.loop2Max = persistedState.limits.loop2Max;
      this.loop3Max = persistedState.limits.loop3Max;
      this.stats = { ...persistedState.stats };
      this.lastUpdated = persistedState.lastUpdated;
      this.initialized = true;

      return true;
    } catch (error) {
      console.error(`Failed to load state for ${phaseId}:`, error.message);
      return false;
    }
  }

  /**
   * Record an escalation event
   * @param {Object} escalation - Escalation details
   * @returns {Promise<Object>} Escalation record
   */
  async recordEscalation(escalation) {
    if (!this.initialized) {
      await this.initialize();
    }

    const escalationRecord = {
      timestamp: new Date().toISOString(),
      phaseId: this.phaseId,
      loop2Counter: this.loop2Counter,
      loop3Counter: this.loop3Counter,
      ...escalation,
    };

    this.escalationHistory.push(escalationRecord);
    this.stats.escalations++;

    // Persist escalation to memory
    const key = `escalation:${this.phaseId}:${Date.now()}`;
    await this.memory.storeCoordination(key, escalationRecord);

    // Update main state
    await this.persistState();

    return escalationRecord;
  }

  /**
   * Get escalation history
   * @returns {Array} List of escalation records
   */
  getEscalationHistory() {
    return [...this.escalationHistory];
  }

  /**
   * Reset all counters (use with caution - typically for new phase)
   * @param {string} reason - Reason for complete reset
   * @returns {Promise<Object>} Reset confirmation
   */
  async resetAll(reason = 'new_phase') {
    if (!this.initialized) {
      await this.initialize();
    }

    const previousState = this.getState();

    this.loop2Counter = 0;
    this.loop3Counter = 0;
    this.lastUpdated = new Date().toISOString();

    // Archive old state if needed
    if (reason === 'new_phase') {
      const archiveKey = `iteration-tracker-archive:${this.phaseId}:${Date.now()}`;
      await this.memory.storeCoordination(archiveKey, previousState);
    }

    // Persist reset state
    await this.persistState();

    return {
      success: true,
      reason,
      previousState,
      currentState: this.getState(),
      message: 'All counters reset',
    };
  }

  /**
   * Get comprehensive statistics
   * @returns {Object} Detailed statistics
   */
  getStatistics() {
    return {
      phaseId: this.phaseId,
      current: {
        loop2: this.loop2Counter,
        loop3: this.loop3Counter,
      },
      limits: {
        loop2Max: this.loop2Max,
        loop3Max: this.loop3Max,
      },
      utilization: {
        loop2: (this.loop2Counter / this.loop2Max) * 100,
        loop3: (this.loop3Counter / this.loop3Max) * 100,
      },
      totals: {
        loop2Iterations: this.stats.totalLoop2Iterations,
        loop3Iterations: this.stats.totalLoop3Iterations,
        loop3Resets: this.stats.loop3Resets,
        escalations: this.stats.escalations,
        successfulGatePasses: this.stats.successfulGatePasses,
      },
      efficiency: {
        averageLoop3PerLoop2:
          this.stats.totalLoop2Iterations > 0
            ? this.stats.totalLoop3Iterations / this.stats.totalLoop2Iterations
            : 0,
        successRate:
          this.stats.totalLoop2Iterations > 0
            ? (this.stats.successfulGatePasses / this.stats.totalLoop2Iterations) * 100
            : 0,
      },
      lastUpdated: this.lastUpdated,
    };
  }

  /**
   * Export state for debugging or analysis
   * @returns {Object} Complete tracker state
   */
  export() {
    return {
      state: this.getState(),
      statistics: this.getStatistics(),
      escalationHistory: this.getEscalationHistory(),
      memoryNamespace: this.memoryNamespace,
      exportedAt: new Date().toISOString(),
    };
  }
}

/**
 * Factory function for easy creation
 * @param {Object} options - Configuration options
 * @returns {IterationTracker} New IterationTracker instance
 */
export function createIterationTracker(options = {}) {
  return new IterationTracker(options);
}

/**
 * Export constants for external use
 */
export { ITERATION_LIMITS, ESCALATION_STRATEGIES };

export default IterationTracker;
