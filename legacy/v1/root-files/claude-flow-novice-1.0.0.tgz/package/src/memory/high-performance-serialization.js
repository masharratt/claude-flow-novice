/**
 * High-Performance Key Serialization and Hashing Algorithms
 *
 * This module implements ultra-fast serialization and hashing algorithms
 * optimized for nanosecond-level performance in the memory store. The
 * algorithms are designed to minimize CPU cycles, memory allocations,
 * and cache misses while maintaining excellent hash distribution.
 */

/**
 * High-performance hash functions optimized for different key types
 */
export class HighPerformanceHash {
  /**
   * XXHash32 - Extremely fast hash function for small to medium keys
   * Optimized for keys up to 64 bytes with excellent distribution
   */
  static xxhash32(key, seed = 0x811C9DC5) {
    if (typeof key === 'string') {
      return this.xxhash32String(key, seed);
    } else if (key instanceof Uint8Array) {
      return this.xxhash32Bytes(key, seed);
    } else {
      return this.xxhash32Generic(key, seed);
    }
  }

  /**
   * Optimized XXHash32 for string keys
   */
  static xxhash32String(str, seed = 0x811C9DC5) {
    const PRIME32_1 = 0x9E3779B1;
    const PRIME32_2 = 0x85EBCA77;
    const PRIME32_3 = 0xC2B2AE3D;
    const PRIME32_4 = 0x27D4EB2F;
    const PRIME32_5 = 0x165667B1;

    let hash = (seed + PRIME32_5) >>> 0;
    const len = str.length;
    let i = 0;

    // Process 4-character chunks
    while (i <= len - 4) {
      let chunk = (str.charCodeAt(i) |
                  (str.charCodeAt(i + 1) << 8) |
                  (str.charCodeAt(i + 2) << 16) |
                  (str.charCodeAt(i + 3) << 24)) >>> 0;

      chunk = Math.imul(chunk, PRIME32_2);
      chunk = ((chunk << 13) | (chunk >>> 19)) >>> 0;
      chunk = Math.imul(chunk, PRIME32_1);

      hash ^= chunk;
      hash = ((hash << 13) | (hash >>> 19)) >>> 0;
      hash = (Math.imul(hash, 5) + 0xE6546B64) >>> 0;
      i += 4;
    }

    // Process remaining characters
    while (i < len) {
      let char = str.charCodeAt(i) >>> 0;
      char = Math.imul(char, PRIME32_5);
      char = ((char << 11) | (char >>> 21)) >>> 0;
      hash ^= char;
      hash = ((hash << 13) | (hash >>> 19)) >>> 0;
      hash = Math.imul(hash, PRIME32_1);
      i++;
    }

    // Final avalanche
    hash ^= len;
    hash ^= hash >>> 16;
    hash = Math.imul(hash, PRIME32_2);
    hash ^= hash >>> 13;
    hash = Math.imul(hash, PRIME32_3);
    hash ^= hash >>> 16;

    return hash >>> 0;
  }

  /**
   * Optimized XXHash32 for byte arrays
   */
  static xxhash32Bytes(bytes, seed = 0x811C9DC5) {
    const PRIME32_1 = 0x9E3779B1;
    const PRIME32_2 = 0x85EBCA77;
    const PRIME32_3 = 0xC2B2AE3D;
    const PRIME32_4 = 0x27D4EB2F;
    const PRIME32_5 = 0x165667B1;

    let hash = (seed + PRIME32_5) >>> 0;
    const len = bytes.length;
    let i = 0;

    // Process 4-byte chunks using DataView for optimal performance
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

    while (i <= len - 4) {
      let chunk = view.getUint32(i, true); // little-endian

      chunk = Math.imul(chunk, PRIME32_2);
      chunk = ((chunk << 13) | (chunk >>> 19)) >>> 0;
      chunk = Math.imul(chunk, PRIME32_1);

      hash ^= chunk;
      hash = ((hash << 13) | (hash >>> 19)) >>> 0;
      hash = (Math.imul(hash, 5) + 0xE6546B64) >>> 0;
      i += 4;
    }

    // Process remaining bytes
    while (i < len) {
      let byte = bytes[i] >>> 0;
      byte = Math.imul(byte, PRIME32_5);
      byte = ((byte << 11) | (byte >>> 21)) >>> 0;
      hash ^= byte;
      hash = ((hash << 13) | (hash >>> 19)) >>> 0;
      hash = Math.imul(hash, PRIME32_1);
      i++;
    }

    // Final avalanche
    hash ^= len;
    hash ^= hash >>> 16;
    hash = Math.imul(hash, PRIME32_2);
    hash ^= hash >>> 13;
    hash = Math.imul(hash, PRIME32_3);
    hash ^= hash >>> 16;

    return hash >>> 0;
  }

  /**
   * Generic XXHash32 for any serializable value
   */
  static xxhash32Generic(value, seed = 0x811C9DC5) {
    const serialized = FastSerializer.serialize(value);
    return this.xxhash32Bytes(serialized, seed);
  }

  /**
   * FNV-1a hash - Fast and simple, good for short keys
   */
  static fnv1a32(key) {
    let hash = 0x811C9DC5;

    if (typeof key === 'string') {
      for (let i = 0; i < key.length; i++) {
        hash ^= key.charCodeAt(i);
        hash = Math.imul(hash, 0x01000193);
      }
    } else if (key instanceof Uint8Array) {
      for (let i = 0; i < key.length; i++) {
        hash ^= key[i];
        hash = Math.imul(hash, 0x01000193);
      }
    } else {
      const serialized = FastSerializer.serialize(key);
      return this.fnv1a32(serialized);
    }

    return hash >>> 0;
  }

  /**
   * CityHash32 variant - Good distribution for medium keys
   */
  static cityHash32(key) {
    const bytes = typeof key === 'string' ? new TextEncoder().encode(key) : key;
    const len = bytes.length;

    if (len <= 4) return this.cityHash32Short(bytes);
    if (len <= 8) return this.cityHash32Medium(bytes);
    return this.cityHash32Long(bytes);
  }

  static cityHash32Short(bytes) {
    const len = bytes.length;
    let a = len;
    let b = len * 5;
    let c = 9;

    if (len >= 1) a ^= bytes[0];
    if (len >= 2) b ^= bytes[1];
    if (len >= 3) c ^= bytes[2];
    if (len >= 4) a ^= bytes[3] << 24;

    return this.cityHashFinalize32(a, b, c);
  }

  static cityHash32Medium(bytes) {
    const len = bytes.length;
    let a = len;
    let b = len * 5;
    let c = 9;

    // Process first 4 bytes
    if (len >= 4) {
      a ^= (bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24)) >>> 0;
    }

    // Process next 4 bytes
    if (len >= 8) {
      b ^= (bytes[4] | (bytes[5] << 8) | (bytes[6] << 16) | (bytes[7] << 24)) >>> 0;
    }

    return this.cityHashFinalize32(a, b, c);
  }

  static cityHash32Long(bytes) {
    // Simplified long version for demonstration
    return this.xxhash32Bytes(bytes);
  }

  static cityHashFinalize32(a, b, c) {
    a = Math.imul(a - c, 0x9E3779B1) >>> 0;
    b = Math.imul(b - a, 0x9E3779B1) >>> 0;
    c = Math.imul(c - b, 0x9E3779B1) >>> 0;
    a = Math.imul(a - c, 0x9E3779B1) >>> 0;
    b = Math.imul(b - a, 0x9E3779B1) >>> 0;
    c = Math.imul(c - b, 0x9E3779B1) >>> 0;
    return c >>> 0;
  }

  /**
   * MurmurHash3 - Excellent distribution for hash tables
   */
  static murmurHash3_32(key, seed = 0x12345678) {
    const bytes = typeof key === 'string' ? new TextEncoder().encode(key) : key;
    const len = bytes.length;
    const c1 = 0xCC9E2D51;
    const c2 = 0x1B873593;
    let h1 = seed;
    let i = 0;

    // Process 4-byte chunks
    while (i <= len - 4) {
      let k1 = (bytes[i] | (bytes[i + 1] << 8) | (bytes[i + 2] << 16) | (bytes[i + 3] << 24)) >>> 0;

      k1 = Math.imul(k1, c1);
      k1 = ((k1 << 15) | (k1 >>> 17)) >>> 0;
      k1 = Math.imul(k1, c2);

      h1 ^= k1;
      h1 = ((h1 << 13) | (h1 >>> 19)) >>> 0;
      h1 = (Math.imul(h1, 5) + 0xE6546B64) >>> 0;
      i += 4;
    }

    // Process remaining bytes
    let k1 = 0;
    switch (len & 3) {
      case 3: k1 ^= bytes[i + 2] << 16;
      case 2: k1 ^= bytes[i + 1] << 8;
      case 1: k1 ^= bytes[i];
        k1 = Math.imul(k1, c1);
        k1 = ((k1 << 15) | (k1 >>> 17)) >>> 0;
        k1 = Math.imul(k1, c2);
        h1 ^= k1;
    }

    // Finalization
    h1 ^= len;
    h1 ^= h1 >>> 16;
    h1 = Math.imul(h1, 0x85EBCA6B);
    h1 ^= h1 >>> 13;
    h1 = Math.imul(h1, 0xC2B2AE35);
    h1 ^= h1 >>> 16;

    return h1 >>> 0;
  }

  /**
   * Select optimal hash function based on key characteristics
   */
  static selectOptimalHash(key) {
    if (typeof key === 'string') {
      if (key.length <= 16) return 'fnv1a32';
      if (key.length <= 64) return 'xxhash32';
      return 'murmurHash3_32';
    } else if (key instanceof Uint8Array) {
      if (key.length <= 4) return 'fnv1a32';
      if (key.length <= 32) return 'xxhash32';
      return 'cityHash32';
    } else {
      return 'xxhash32'; // Default for generic objects
    }
  }

  /**
   * Adaptive hash function that selects the best algorithm
   */
  static adaptiveHash(key, seed = 0x811C9DC5) {
    const algorithm = this.selectOptimalHash(key);

    switch (algorithm) {
      case 'fnv1a32': return this.fnv1a32(key);
      case 'xxhash32': return this.xxhash32(key, seed);
      case 'murmurHash3_32': return this.murmurHash3_32(key, seed);
      case 'cityHash32': return this.cityHash32(key);
      default: return this.xxhash32(key, seed);
    }
  }
}

/**
 * Ultra-fast serialization for JavaScript values
 */
export class FastSerializer {
  /**
   * Serialize JavaScript value to Uint8Array with minimal overhead
   */
  static serialize(value) {
    const type = typeof value;

    switch (type) {
      case 'string':
        return this.serializeString(value);
      case 'number':
        return this.serializeNumber(value);
      case 'boolean':
        return this.serializeBoolean(value);
      case 'object':
        if (value === null) return this.serializeNull();
        if (value instanceof Uint8Array) return value;
        if (value instanceof ArrayBuffer) return new Uint8Array(value);
        if (Array.isArray(value)) return this.serializeArray(value);
        return this.serializeObject(value);
      case 'undefined':
        return this.serializeUndefined();
      default:
        return this.serializeString(String(value));
    }
  }

  /**
   * High-performance string serialization using TextEncoder
   */
  static serializeString(str) {
    // Cache TextEncoder instance for reuse
    if (!this._textEncoder) {
      this._textEncoder = new TextEncoder();
    }

    const encoded = this._textEncoder.encode(str);
    const result = new Uint8Array(encoded.length + 5);

    result[0] = 0x01; // String type marker
    result[1] = (encoded.length >>> 24) & 0xFF;
    result[2] = (encoded.length >>> 16) & 0xFF;
    result[3] = (encoded.length >>> 8) & 0xFF;
    result[4] = encoded.length & 0xFF;
    result.set(encoded, 5);

    return result;
  }

  /**
   * Optimized number serialization
   */
  static serializeNumber(num) {
    const result = new Uint8Array(9);
    const view = new DataView(result.buffer);

    result[0] = 0x02; // Number type marker
    view.setFloat64(1, num, true); // little-endian

    return result;
  }

  /**
   * Compact boolean serialization
   */
  static serializeBoolean(bool) {
    return new Uint8Array([0x03, bool ? 1 : 0]);
  }

  /**
   * Null value serialization
   */
  static serializeNull() {
    return new Uint8Array([0x04]);
  }

  /**
   * Undefined value serialization
   */
  static serializeUndefined() {
    return new Uint8Array([0x05]);
  }

  /**
   * Array serialization with length prefix
   */
  static serializeArray(arr) {
    const serializedItems = arr.map(item => this.serialize(item));
    const totalLength = serializedItems.reduce((sum, item) => sum + item.length, 0);

    const result = new Uint8Array(totalLength + 5);
    const view = new DataView(result.buffer);

    result[0] = 0x06; // Array type marker
    view.setUint32(1, arr.length, true); // little-endian

    let offset = 5;
    for (const item of serializedItems) {
      result.set(item, offset);
      offset += item.length;
    }

    return result;
  }

  /**
   * Object serialization with key sorting for deterministic output
   */
  static serializeObject(obj) {
    const keys = Object.keys(obj).sort(); // Deterministic key order
    const serializedPairs = [];

    for (const key of keys) {
      const serializedKey = this.serializeString(key);
      const serializedValue = this.serialize(obj[key]);
      serializedPairs.push(serializedKey, serializedValue);
    }

    const totalLength = serializedPairs.reduce((sum, item) => sum + item.length, 0);
    const result = new Uint8Array(totalLength + 5);
    const view = new DataView(result.buffer);

    result[0] = 0x07; // Object type marker
    view.setUint32(1, keys.length, true); // Number of key-value pairs

    let offset = 5;
    for (const item of serializedPairs) {
      result.set(item, offset);
      offset += item.length;
    }

    return result;
  }

  /**
   * Deserialize Uint8Array back to JavaScript value
   */
  static deserialize(bytes) {
    if (bytes.length === 0) return undefined;

    const type = bytes[0];
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

    switch (type) {
      case 0x01: return this.deserializeString(bytes, view);
      case 0x02: return this.deserializeNumber(view);
      case 0x03: return this.deserializeBoolean(bytes);
      case 0x04: return null;
      case 0x05: return undefined;
      case 0x06: return this.deserializeArray(bytes, view);
      case 0x07: return this.deserializeObject(bytes, view);
      default: throw new Error(`Unknown type marker: ${type}`);
    }
  }

  static deserializeString(bytes, view) {
    if (!this._textDecoder) {
      this._textDecoder = new TextDecoder();
    }

    const length = view.getUint32(1, true);
    const stringBytes = bytes.slice(5, 5 + length);
    return this._textDecoder.decode(stringBytes);
  }

  static deserializeNumber(view) {
    return view.getFloat64(1, true);
  }

  static deserializeBoolean(bytes) {
    return bytes[1] === 1;
  }

  static deserializeArray(bytes, view) {
    const length = view.getUint32(1, true);
    const result = new Array(length);
    let offset = 5;

    for (let i = 0; i < length; i++) {
      const itemType = bytes[offset];
      const itemEnd = this.findItemEnd(bytes, offset);
      const itemBytes = bytes.slice(offset, itemEnd);
      result[i] = this.deserialize(itemBytes);
      offset = itemEnd;
    }

    return result;
  }

  static deserializeObject(bytes, view) {
    const pairCount = view.getUint32(1, true);
    const result = {};
    let offset = 5;

    for (let i = 0; i < pairCount; i++) {
      // Deserialize key
      const keyEnd = this.findItemEnd(bytes, offset);
      const keyBytes = bytes.slice(offset, keyEnd);
      const key = this.deserialize(keyBytes);
      offset = keyEnd;

      // Deserialize value
      const valueEnd = this.findItemEnd(bytes, offset);
      const valueBytes = bytes.slice(offset, valueEnd);
      const value = this.deserialize(valueBytes);
      offset = valueEnd;

      result[key] = value;
    }

    return result;
  }

  static findItemEnd(bytes, start) {
    const type = bytes[start];
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

    switch (type) {
      case 0x01: // String
        const strLength = view.getUint32(start + 1, true);
        return start + 5 + strLength;
      case 0x02: // Number
        return start + 9;
      case 0x03: // Boolean
        return start + 2;
      case 0x04: // Null
      case 0x05: // Undefined
        return start + 1;
      case 0x06: // Array
      case 0x07: // Object
        // Complex types require recursive parsing
        return this.findComplexItemEnd(bytes, start);
      default:
        throw new Error(`Unknown type marker: ${type}`);
    }
  }

  static findComplexItemEnd(bytes, start) {
    // Simplified implementation - in practice would need full recursive parsing
    // This is a placeholder that should be implemented based on the specific format
    throw new Error('Complex type end finding not implemented');
  }
}

/**
 * Namespace-aware key serialization
 */
export class NamespaceKeySerializer {
  /**
   * Serialize key with namespace information
   */
  static serializeNamespacedKey(namespace, key) {
    const namespaceBytes = FastSerializer.serialize(namespace);
    const keyBytes = FastSerializer.serialize(key);

    const result = new Uint8Array(namespaceBytes.length + keyBytes.length + 8);
    const view = new DataView(result.buffer);

    // Header: namespace length + key length
    view.setUint32(0, namespaceBytes.length, true);
    view.setUint32(4, keyBytes.length, true);

    // Data: namespace + key
    result.set(namespaceBytes, 8);
    result.set(keyBytes, 8 + namespaceBytes.length);

    return result;
  }

  /**
   * Generate composite hash for namespaced key
   */
  static hashNamespacedKey(namespace, key, seed = 0x12345678) {
    const namespaceHash = HighPerformanceHash.adaptiveHash(namespace, seed);
    const keyHash = HighPerformanceHash.adaptiveHash(key, namespaceHash);

    // Combine hashes using multiplication and XOR
    return Math.imul(namespaceHash, 0x9E3779B1) ^ keyHash;
  }

  /**
   * Fast namespace ID lookup with caching
   */
  static resolveNamespace(namespaceName, namespaceMap) {
    let namespaceId = namespaceMap.get(namespaceName);

    if (namespaceId === undefined) {
      namespaceId = HighPerformanceHash.fnv1a32(namespaceName);
      namespaceMap.set(namespaceName, namespaceId);
    }

    return namespaceId;
  }
}

/**
 * Performance benchmarking for serialization and hashing
 */
export class SerializationBenchmark {
  constructor() {
    this.results = new Map();
  }

  /**
   * Benchmark hash function performance
   */
  benchmarkHashFunctions(testData, iterations = 100000) {
    const functions = [
      'fnv1a32',
      'xxhash32',
      'murmurHash3_32',
      'cityHash32',
      'adaptiveHash'
    ];

    const results = {};

    for (const funcName of functions) {
      const start = performance.now() * 1000000; // nanoseconds

      for (let i = 0; i < iterations; i++) {
        HighPerformanceHash[funcName](testData);
      }

      const end = performance.now() * 1000000;
      const avgTime = (end - start) / iterations;

      results[funcName] = {
        totalTime: end - start,
        avgTimePerOp: avgTime,
        operationsPerSecond: 1000000000 / avgTime
      };
    }

    return results;
  }

  /**
   * Benchmark serialization performance
   */
  benchmarkSerialization(testData, iterations = 50000) {
    const results = {};

    // Serialization benchmark
    const start = performance.now() * 1000000;

    for (let i = 0; i < iterations; i++) {
      FastSerializer.serialize(testData);
    }

    const end = performance.now() * 1000000;

    results.serialization = {
      totalTime: end - start,
      avgTimePerOp: (end - start) / iterations,
      operationsPerSecond: 1000000000 / ((end - start) / iterations)
    };

    // Round-trip benchmark
    const serialized = FastSerializer.serialize(testData);
    const roundTripStart = performance.now() * 1000000;

    for (let i = 0; i < iterations; i++) {
      const data = FastSerializer.serialize(testData);
      FastSerializer.deserialize(data);
    }

    const roundTripEnd = performance.now() * 1000000;

    results.roundTrip = {
      totalTime: roundTripEnd - roundTripStart,
      avgTimePerOp: (roundTripEnd - roundTripStart) / iterations,
      operationsPerSecond: 1000000000 / ((roundTripEnd - roundTripStart) / iterations),
      serializedSize: serialized.length
    };

    return results;
  }

  /**
   * Hash distribution quality test
   */
  testHashDistribution(hashFunction, keyGenerator, bucketCount = 10000, keyCount = 100000) {
    const buckets = new Array(bucketCount).fill(0);

    for (let i = 0; i < keyCount; i++) {
      const key = keyGenerator(i);
      const hash = HighPerformanceHash[hashFunction](key);
      const bucketIndex = hash % bucketCount;
      buckets[bucketIndex]++;
    }

    // Calculate distribution metrics
    const expectedPerBucket = keyCount / bucketCount;
    let sumSquaredDiffs = 0;
    let minBucket = buckets[0];
    let maxBucket = buckets[0];

    for (const count of buckets) {
      const diff = count - expectedPerBucket;
      sumSquaredDiffs += diff * diff;
      minBucket = Math.min(minBucket, count);
      maxBucket = Math.max(maxBucket, count);
    }

    const variance = sumSquaredDiffs / bucketCount;
    const stdDev = Math.sqrt(variance);
    const coefficient = stdDev / expectedPerBucket;

    return {
      minBucket,
      maxBucket,
      expectedPerBucket,
      variance,
      stdDev,
      coefficientOfVariation: coefficient,
      quality: coefficient < 0.1 ? 'Excellent' :
               coefficient < 0.2 ? 'Good' :
               coefficient < 0.3 ? 'Fair' : 'Poor'
    };
  }

  /**
   * Generate comprehensive performance report
   */
  generatePerformanceReport(testCases) {
    const report = {
      timestamp: Date.now(),
      hashFunctions: {},
      serialization: {},
      distribution: {}
    };

    for (const testCase of testCases) {
      // Hash function benchmarks
      report.hashFunctions[testCase.name] = this.benchmarkHashFunctions(
        testCase.data, testCase.iterations
      );

      // Serialization benchmarks
      report.serialization[testCase.name] = this.benchmarkSerialization(
        testCase.data, testCase.iterations
      );

      // Distribution quality tests
      report.distribution[testCase.name] = {};
      const functions = ['fnv1a32', 'xxhash32', 'murmurHash3_32'];
      for (const func of functions) {
        report.distribution[testCase.name][func] = this.testHashDistribution(
          func, testCase.keyGenerator
        );
      }
    }

    return report;
  }
}

// Export commonly used combinations
export const DefaultHashFunction = HighPerformanceHash.xxhash32;
export const FastHash = HighPerformanceHash.fnv1a32;
export const QualityHash = HighPerformanceHash.murmurHash3_32;