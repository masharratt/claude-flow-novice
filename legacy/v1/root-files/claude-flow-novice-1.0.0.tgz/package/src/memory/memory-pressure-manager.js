/**
 * Memory Pressure Management and Eviction Policies
 *
 * This module implements sophisticated memory pressure management with multiple
 * eviction policies optimized for ultra-high-performance scenarios. The system
 * uses lock-free algorithms to maintain sub-microsecond performance even during
 * memory cleanup operations.
 */

import { AtomicOperations } from './lock-free-structures.js';

/**
 * Memory pressure thresholds and configuration
 */
const MEMORY_PRESSURE_CONFIG = {
  // Pressure thresholds (utilization percentages)
  LOW_PRESSURE: 0.60,      // 60% - Start background cleanup
  MEDIUM_PRESSURE: 0.75,   // 75% - Aggressive cleanup
  HIGH_PRESSURE: 0.85,     // 85% - Block new allocations
  CRITICAL_PRESSURE: 0.95, // 95% - Emergency cleanup

  // Eviction batch sizes
  BACKGROUND_BATCH: 64,    // Background cleanup batch
  AGGRESSIVE_BATCH: 256,   // Aggressive cleanup batch
  EMERGENCY_BATCH: 1024,   // Emergency cleanup batch

  // Timing thresholds (nanoseconds)
  RECENCY_THRESHOLD: 1000000000,  // 1 second
  FREQUENCY_THRESHOLD: 10,        // Access count threshold
  AGE_THRESHOLD: 5000000000,      // 5 seconds

  // Clock algorithm parameters
  CLOCK_SEGMENTS: 8,              // Number of clock segments
  REFERENCE_BITS: 2,              // Reference bit count (2^n levels)
};

/**
 * Entry metadata for eviction algorithms
 */
const ENTRY_METADATA_LAYOUT = {
  accessCount: 0,          // uint32 - Access frequency counter
  lastAccess: 4,           // uint64 - Last access timestamp (ns)
  creationTime: 12,        // uint64 - Creation timestamp (ns)
  referenceLevel: 20,      // uint8  - Reference level (0-3)
  evictionScore: 21,       // uint8  - Calculated eviction score
  flags: 22,               // uint16 - Entry flags
  // Total: 24 bytes per entry
};

/**
 * Advanced memory pressure manager with multiple eviction strategies
 */
export class AdvancedMemoryPressureManager {
  constructor(memoryStore, config = MEMORY_PRESSURE_CONFIG) {
    this.store = memoryStore;
    this.config = config;

    // Current pressure state
    this.currentPressure = 0.0;
    this.pressureLevel = 'LOW';
    this.lastCleanup = 0;

    // Clock algorithm state
    this.clockHands = new Array(this.config.CLOCK_SEGMENTS).fill(0);
    this.currentClockSegment = 0;

    // Eviction statistics
    this.stats = {
      totalEvictions: 0,
      evictionsByReason: new Map(),
      avgEvictionTime: 0,
      lastPressureCheck: 0,
      backgroundCleanups: 0
    };

    // Access pattern analyzer
    this.accessAnalyzer = new AccessPatternAnalyzer();

    this.initializeMetadataRegion();
    this.startBackgroundCleanup();
  }

  /**
   * Initialize metadata region for entry tracking
   */
  initializeMetadataRegion() {
    const entryCount = this.store.maxEntries;
    const metadataSize = entryCount * 24; // 24 bytes per entry metadata

    this.metadataOffset = this.store.poolOffset - metadataSize;
    this.metadataBuffer = new ArrayBuffer(metadataSize);
    this.metadataView = new DataView(this.metadataBuffer);

    // Clear metadata region
    for (let i = 0; i < metadataSize; i += 4) {
      this.metadataView.setUint32(i, 0);
    }
  }

  /**
   * Check memory pressure and trigger appropriate response
   */
  checkMemoryPressure() {
    const startTime = performance.now() * 1000000;

    const totalMemory = this.store.totalSize;
    const usedMemory = this.calculateUsedMemory();
    const pressure = usedMemory / totalMemory;

    this.currentPressure = pressure;
    this.stats.lastPressureCheck = startTime;

    // Determine pressure level
    const previousLevel = this.pressureLevel;
    if (pressure >= this.config.CRITICAL_PRESSURE) {
      this.pressureLevel = 'CRITICAL';
    } else if (pressure >= this.config.HIGH_PRESSURE) {
      this.pressureLevel = 'HIGH';
    } else if (pressure >= this.config.MEDIUM_PRESSURE) {
      this.pressureLevel = 'MEDIUM';
    } else if (pressure >= this.config.LOW_PRESSURE) {
      this.pressureLevel = 'LOW';
    } else {
      this.pressureLevel = 'NORMAL';
    }

    // React to pressure level changes
    if (this.pressureLevel !== previousLevel) {
      this.onPressureLevelChange(previousLevel, this.pressureLevel);
    }

    // Trigger appropriate cleanup strategy
    switch (this.pressureLevel) {
      case 'CRITICAL':
        return this.emergencyCleanup();
      case 'HIGH':
        return this.aggressiveCleanup();
      case 'MEDIUM':
        return this.adaptiveCleanup();
      case 'LOW':
        return this.backgroundCleanup();
      default:
        return false;
    }
  }

  /**
   * Emergency cleanup - most aggressive eviction
   */
  emergencyCleanup() {
    const startTime = performance.now() * 1000000;
    let evicted = 0;
    const targetEvictions = this.config.EMERGENCY_BATCH;

    // Use simple age-based eviction for speed
    const entries = this.getAllEntries();
    entries.sort((a, b) => a.lastAccess - b.lastAccess);

    for (let i = 0; i < Math.min(targetEvictions, entries.length); i++) {
      if (this.tryEvictEntry(entries[i], 'EMERGENCY_AGE')) {
        evicted++;
      }
    }

    this.recordEvictionStats('EMERGENCY', evicted, startTime);
    return evicted > 0;
  }

  /**
   * Aggressive cleanup using combined scoring
   */
  aggressiveCleanup() {
    const startTime = performance.now() * 1000000;
    let evicted = 0;
    const targetEvictions = this.config.AGGRESSIVE_BATCH;

    // Calculate eviction scores for all entries
    const scoredEntries = this.calculateEvictionScores();
    scoredEntries.sort((a, b) => b.score - a.score); // Highest score = most evictable

    for (let i = 0; i < Math.min(targetEvictions, scoredEntries.length); i++) {
      if (this.tryEvictEntry(scoredEntries[i].entry, 'AGGRESSIVE_SCORE')) {
        evicted++;
      }
    }

    this.recordEvictionStats('AGGRESSIVE', evicted, startTime);
    return evicted > 0;
  }

  /**
   * Adaptive cleanup based on access patterns
   */
  adaptiveCleanup() {
    const startTime = performance.now() * 1000000;
    const accessPattern = this.accessAnalyzer.getCurrentPattern();

    let evicted = 0;
    switch (accessPattern.type) {
      case 'SEQUENTIAL':
        evicted = this.sequentialEviction();
        break;
      case 'RANDOM':
        evicted = this.clockEviction();
        break;
      case 'HOTSPOT':
        evicted = this.lruEviction();
        break;
      case 'TEMPORAL':
        evicted = this.temporalEviction();
        break;
      default:
        evicted = this.clockEviction();
    }

    this.recordEvictionStats('ADAPTIVE', evicted, startTime);
    return evicted > 0;
  }

  /**
   * Background cleanup - least intrusive
   */
  backgroundCleanup() {
    if (this.isBackgroundCleanupDue()) {
      const startTime = performance.now() * 1000000;
      const evicted = this.incrementalClockEviction();

      this.stats.backgroundCleanups++;
      this.recordEvictionStats('BACKGROUND', evicted, startTime);
      this.lastCleanup = startTime;

      return evicted > 0;
    }
    return false;
  }

  /**
   * Enhanced Clock algorithm with reference levels
   */
  clockEviction() {
    const targetEvictions = this.config.AGGRESSIVE_BATCH;
    const clockSegment = this.currentClockSegment;
    let evicted = 0;
    let scanned = 0;
    const maxScan = this.store.maxEntries;

    while (evicted < targetEvictions && scanned < maxScan) {
      const entryIndex = this.clockHands[clockSegment];
      const entry = this.getEntryByIndex(entryIndex);

      if (entry) {
        const referenceLevel = this.getEntryReferenceLevel(entry);

        if (referenceLevel === 0) {
          // Reference level is 0, evict this entry
          if (this.tryEvictEntry(entry, 'CLOCK_EVICTION')) {
            evicted++;
          }
        } else {
          // Decrement reference level
          this.decrementReferenceLevel(entry);
        }
      }

      // Advance clock hand
      this.clockHands[clockSegment] = (entryIndex + 1) % this.store.maxEntries;
      scanned++;
    }

    this.currentClockSegment = (clockSegment + 1) % this.config.CLOCK_SEGMENTS;
    return evicted;
  }

  /**
   * Incremental clock eviction for background cleanup
   */
  incrementalClockEviction() {
    const targetEvictions = this.config.BACKGROUND_BATCH;
    const segmentSize = Math.ceil(this.store.maxEntries / this.config.CLOCK_SEGMENTS);
    const clockSegment = this.currentClockSegment;

    let evicted = 0;
    const startIndex = this.clockHands[clockSegment];
    const endIndex = Math.min(startIndex + segmentSize, this.store.maxEntries);

    for (let i = startIndex; i < endIndex && evicted < targetEvictions; i++) {
      const entry = this.getEntryByIndex(i);
      if (entry) {
        const age = this.getEntryAge(entry);
        const accessCount = this.getEntryAccessCount(entry);

        // Simple heuristic: evict if old and infrequently accessed
        if (age > this.config.AGE_THRESHOLD && accessCount < this.config.FREQUENCY_THRESHOLD) {
          if (this.tryEvictEntry(entry, 'BACKGROUND_AGE')) {
            evicted++;
          }
        }
      }
    }

    this.clockHands[clockSegment] = endIndex % this.store.maxEntries;
    return evicted;
  }

  /**
   * LRU eviction using access timestamps
   */
  lruEviction() {
    const targetEvictions = this.config.AGGRESSIVE_BATCH;
    const entries = this.getAllEntries();

    // Sort by last access time (oldest first)
    entries.sort((a, b) => this.getEntryLastAccess(a) - this.getEntryLastAccess(b));

    let evicted = 0;
    for (let i = 0; i < Math.min(targetEvictions, entries.length); i++) {
      if (this.tryEvictEntry(entries[i], 'LRU_EVICTION')) {
        evicted++;
      }
    }

    return evicted;
  }

  /**
   * Sequential access pattern eviction (FIFO-like)
   */
  sequentialEviction() {
    const targetEvictions = this.config.AGGRESSIVE_BATCH;
    const entries = this.getAllEntries();

    // Sort by creation time (oldest first)
    entries.sort((a, b) => this.getEntryCreationTime(a) - this.getEntryCreationTime(b));

    let evicted = 0;
    for (let i = 0; i < Math.min(targetEvictions, entries.length); i++) {
      if (this.tryEvictEntry(entries[i], 'SEQUENTIAL_FIFO')) {
        evicted++;
      }
    }

    return evicted;
  }

  /**
   * Temporal locality eviction - evict entries with poor temporal locality
   */
  temporalEviction() {
    const targetEvictions = this.config.AGGRESSIVE_BATCH;
    const entries = this.getAllEntries();
    const now = performance.now() * 1000000;

    // Calculate temporal locality score
    const temporalScores = entries.map(entry => ({
      entry,
      score: this.calculateTemporalLocalityScore(entry, now)
    }));

    // Sort by temporal locality score (worst first)
    temporalScores.sort((a, b) => b.score - a.score);

    let evicted = 0;
    for (let i = 0; i < Math.min(targetEvictions, temporalScores.length); i++) {
      if (this.tryEvictEntry(temporalScores[i].entry, 'TEMPORAL_LOCALITY')) {
        evicted++;
      }
    }

    return evicted;
  }

  /**
   * Calculate comprehensive eviction scores
   */
  calculateEvictionScores() {
    const entries = this.getAllEntries();
    const now = performance.now() * 1000000;

    return entries.map(entry => {
      const age = now - this.getEntryCreationTime(entry);
      const recency = now - this.getEntryLastAccess(entry);
      const frequency = this.getEntryAccessCount(entry);
      const size = this.getEntrySize(entry);

      // Multi-factor scoring algorithm
      let score = 0;

      // Age factor (older = higher score)
      score += Math.min(age / this.config.AGE_THRESHOLD, 1.0) * 30;

      // Recency factor (less recent = higher score)
      score += Math.min(recency / this.config.RECENCY_THRESHOLD, 1.0) * 25;

      // Frequency factor (less frequent = higher score)
      score += Math.max(0, 1.0 - frequency / this.config.FREQUENCY_THRESHOLD) * 25;

      // Size factor (larger = higher score)
      score += Math.min(size / 1024, 1.0) * 20; // Normalize by 1KB

      return { entry, score };
    });
  }

  /**
   * Calculate temporal locality score
   */
  calculateTemporalLocalityScore(entry, currentTime) {
    const lastAccess = this.getEntryLastAccess(entry);
    const accessCount = this.getEntryAccessCount(entry);
    const age = currentTime - this.getEntryCreationTime(entry);

    // Poor temporal locality = high score (more evictable)
    const recencyScore = (currentTime - lastAccess) / this.config.RECENCY_THRESHOLD;
    const frequencyScore = Math.max(0, 1.0 - accessCount / this.config.FREQUENCY_THRESHOLD);
    const ageScore = age / this.config.AGE_THRESHOLD;

    return (recencyScore * 0.4 + frequencyScore * 0.4 + ageScore * 0.2);
  }

  /**
   * Try to evict a specific entry
   */
  tryEvictEntry(entry, reason) {
    if (!entry || this.isEntryPinned(entry)) {
      return false;
    }

    // Attempt to mark entry as deleted
    const flags = this.getEntryFlags(entry);
    const deletedFlag = flags | 0x80000000;

    const success = AtomicOperations.compareAndSwap32(
      this.store.buffer, entry.offset + 24, flags, deletedFlag
    );

    if (success === flags) {
      // Update statistics
      this.stats.totalEvictions++;
      if (!this.stats.evictionsByReason.has(reason)) {
        this.stats.evictionsByReason.set(reason, 0);
      }
      this.stats.evictionsByReason.set(reason,
        this.stats.evictionsByReason.get(reason) + 1);

      // Clear metadata
      this.clearEntryMetadata(entry);

      // Add to free list
      this.store.memoryPool.deallocate(entry.offset);

      return true;
    }

    return false;
  }

  /**
   * Update entry access metadata
   */
  updateEntryAccess(entry) {
    const now = performance.now() * 1000000;
    const metadataOffset = this.getEntryMetadataOffset(entry);

    // Update access count atomically
    AtomicOperations.atomicIncrement(this.metadataBuffer, metadataOffset + ENTRY_METADATA_LAYOUT.accessCount);

    // Update last access timestamp
    AtomicOperations.storeRelease(this.metadataBuffer, metadataOffset + ENTRY_METADATA_LAYOUT.lastAccess, now);

    // Update reference level (for clock algorithm)
    const currentLevel = this.metadataView.getUint8(metadataOffset + ENTRY_METADATA_LAYOUT.referenceLevel);
    const newLevel = Math.min(currentLevel + 1, (1 << this.config.REFERENCE_BITS) - 1);
    this.metadataView.setUint8(metadataOffset + ENTRY_METADATA_LAYOUT.referenceLevel, newLevel);

    // Record access pattern
    this.accessAnalyzer.recordAccess(entry, now);
  }

  /**
   * Memory pressure management utilities
   */
  calculateUsedMemory() {
    const entryCount = AtomicOperations.loadAcquire(this.store.buffer, this.store.headerLayout.entryCount);
    const avgEntrySize = this.calculateAverageEntrySize();
    return entryCount * avgEntrySize;
  }

  calculateAverageEntrySize() {
    const samples = Math.min(100, this.store.maxEntries);
    let totalSize = 0;
    let sampleCount = 0;

    for (let i = 0; i < samples; i++) {
      const entry = this.getEntryByIndex(i);
      if (entry) {
        totalSize += this.getEntrySize(entry);
        sampleCount++;
      }
    }

    return sampleCount > 0 ? Math.ceil(totalSize / sampleCount) : 64;
  }

  isBackgroundCleanupDue() {
    const now = performance.now() * 1000000;
    const timeSinceLastCleanup = now - this.lastCleanup;
    return timeSinceLastCleanup > 1000000000; // 1 second
  }

  onPressureLevelChange(oldLevel, newLevel) {
    console.log(`Memory pressure changed: ${oldLevel} -> ${newLevel} (${(this.currentPressure * 100).toFixed(1)}%)`);

    // Adjust background cleanup frequency
    if (newLevel === 'HIGH' || newLevel === 'CRITICAL') {
      this.increaseCleanupFrequency();
    } else if (newLevel === 'NORMAL' || newLevel === 'LOW') {
      this.normalizeCleanupFrequency();
    }
  }

  /**
   * Entry metadata access methods
   */
  getEntryMetadataOffset(entry) {
    return entry.index * 24; // 24 bytes per entry metadata
  }

  getEntryAccessCount(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    return AtomicOperations.loadAcquire(this.metadataBuffer, metadataOffset + ENTRY_METADATA_LAYOUT.accessCount);
  }

  getEntryLastAccess(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    return AtomicOperations.loadAcquire(this.metadataBuffer, metadataOffset + ENTRY_METADATA_LAYOUT.lastAccess);
  }

  getEntryCreationTime(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    return AtomicOperations.loadAcquire(this.metadataBuffer, metadataOffset + ENTRY_METADATA_LAYOUT.creationTime);
  }

  getEntryReferenceLevel(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    return this.metadataView.getUint8(metadataOffset + ENTRY_METADATA_LAYOUT.referenceLevel);
  }

  decrementReferenceLevel(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    const currentLevel = this.metadataView.getUint8(metadataOffset + ENTRY_METADATA_LAYOUT.referenceLevel);
    const newLevel = Math.max(0, currentLevel - 1);
    this.metadataView.setUint8(metadataOffset + ENTRY_METADATA_LAYOUT.referenceLevel, newLevel);
  }

  clearEntryMetadata(entry) {
    const metadataOffset = this.getEntryMetadataOffset(entry);
    for (let i = 0; i < 24; i += 4) {
      AtomicOperations.storeRelease(this.metadataBuffer, metadataOffset + i, 0);
    }
  }

  /**
   * Statistics and monitoring
   */
  recordEvictionStats(type, evictedCount, startTime) {
    const endTime = performance.now() * 1000000;
    const duration = endTime - startTime;

    this.stats.avgEvictionTime = (this.stats.avgEvictionTime + duration) / 2;
    console.log(`${type} eviction: ${evictedCount} entries in ${(duration / 1000).toFixed(2)}μs`);
  }

  getMemoryPressureStats() {
    return {
      currentPressure: this.currentPressure,
      pressureLevel: this.pressureLevel,
      totalEvictions: this.stats.totalEvictions,
      evictionsByReason: Object.fromEntries(this.stats.evictionsByReason),
      avgEvictionTime: this.stats.avgEvictionTime,
      backgroundCleanups: this.stats.backgroundCleanups,
      accessPattern: this.accessAnalyzer.getCurrentPattern()
    };
  }

  /**
   * Start background cleanup process
   */
  startBackgroundCleanup() {
    setInterval(() => {
      if (this.currentPressure > this.config.LOW_PRESSURE) {
        this.checkMemoryPressure();
      }
    }, 100); // Check every 100ms
  }

  // Placeholder methods for entry access (to be implemented by memory store)
  getAllEntries() { return []; }
  getEntryByIndex(index) { return null; }
  getEntryAge(entry) { return 0; }
  getEntrySize(entry) { return 64; }
  getEntryFlags(entry) { return 0; }
  isEntryPinned(entry) { return false; }
  increaseCleanupFrequency() { /* Implementation needed */ }
  normalizeCleanupFrequency() { /* Implementation needed */ }
}

/**
 * Access pattern analyzer for adaptive eviction
 */
class AccessPatternAnalyzer {
  constructor() {
    this.accessHistory = [];
    this.maxHistorySize = 1000;
    this.patternWindow = 100;

    this.patterns = {
      SEQUENTIAL: 0,
      RANDOM: 0,
      HOTSPOT: 0,
      TEMPORAL: 0
    };

    this.currentPattern = { type: 'RANDOM', confidence: 0.5 };
  }

  recordAccess(entry, timestamp) {
    this.accessHistory.push({
      entryId: entry.id || entry.offset,
      timestamp,
      namespace: entry.namespace
    });

    if (this.accessHistory.length > this.maxHistorySize) {
      this.accessHistory.shift();
    }

    // Analyze pattern periodically
    if (this.accessHistory.length % this.patternWindow === 0) {
      this.analyzePattern();
    }
  }

  analyzePattern() {
    if (this.accessHistory.length < this.patternWindow) {
      return;
    }

    const recent = this.accessHistory.slice(-this.patternWindow);

    // Reset pattern scores
    for (const pattern in this.patterns) {
      this.patterns[pattern] = 0;
    }

    // Analyze sequential access pattern
    let sequentialScore = this.calculateSequentialScore(recent);
    this.patterns.SEQUENTIAL = sequentialScore;

    // Analyze random access pattern
    let randomScore = this.calculateRandomScore(recent);
    this.patterns.RANDOM = randomScore;

    // Analyze hotspot pattern
    let hotspotScore = this.calculateHotspotScore(recent);
    this.patterns.HOTSPOT = hotspotScore;

    // Analyze temporal locality pattern
    let temporalScore = this.calculateTemporalScore(recent);
    this.patterns.TEMPORAL = temporalScore;

    // Determine dominant pattern
    let maxScore = 0;
    let dominantPattern = 'RANDOM';

    for (const [pattern, score] of Object.entries(this.patterns)) {
      if (score > maxScore) {
        maxScore = score;
        dominantPattern = pattern;
      }
    }

    this.currentPattern = {
      type: dominantPattern,
      confidence: maxScore,
      scores: { ...this.patterns }
    };
  }

  calculateSequentialScore(accesses) {
    let sequentialCount = 0;
    const entryIds = accesses.map(a => a.entryId).sort((a, b) => a - b);

    for (let i = 1; i < entryIds.length; i++) {
      if (entryIds[i] - entryIds[i-1] === 1) {
        sequentialCount++;
      }
    }

    return sequentialCount / (entryIds.length - 1);
  }

  calculateRandomScore(accesses) {
    const uniqueEntries = new Set(accesses.map(a => a.entryId));
    const uniqueRatio = uniqueEntries.size / accesses.length;
    return uniqueRatio; // Higher ratio = more random
  }

  calculateHotspotScore(accesses) {
    const entryFreq = new Map();
    for (const access of accesses) {
      entryFreq.set(access.entryId, (entryFreq.get(access.entryId) || 0) + 1);
    }

    const frequencies = Array.from(entryFreq.values()).sort((a, b) => b - a);
    const top20Percent = Math.ceil(frequencies.length * 0.2);
    const hotspotAccesses = frequencies.slice(0, top20Percent).reduce((a, b) => a + b, 0);

    return hotspotAccesses / accesses.length;
  }

  calculateTemporalScore(accesses) {
    const entryLastAccess = new Map();
    let temporalHits = 0;

    for (const access of accesses) {
      const lastAccess = entryLastAccess.get(access.entryId);
      if (lastAccess && access.timestamp - lastAccess < 1000000000) { // 1 second
        temporalHits++;
      }
      entryLastAccess.set(access.entryId, access.timestamp);
    }

    return temporalHits / accesses.length;
  }

  getCurrentPattern() {
    return this.currentPattern;
  }
}

export { AccessPatternAnalyzer, MEMORY_PRESSURE_CONFIG };