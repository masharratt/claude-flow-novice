/**
 * Memory-Mapped File Persistence for Ultra-Fast Backup and Restore
 *
 * This module implements high-performance persistence using memory-mapped files,
 * incremental backups, and atomic operations to ensure data integrity while
 * maintaining sub-microsecond performance for the in-memory operations.
 */

import { promises as fs, constants } from 'fs';
import { AtomicOperations } from './lock-free-structures.js';

/**
 * Memory-mapped persistence configuration
 */
const PERSISTENCE_CONFIG = {
  // File layout constants
  HEADER_SIZE: 1024,           // File header size
  REGION_SIZE: 4096,           // Memory region size (4KB pages)
  CHECKPOINT_INTERVAL: 5000,   // Checkpoint interval (ms)
  SYNC_BATCH_SIZE: 16,         // Number of regions to sync per batch

  // Backup strategies
  INCREMENTAL_THRESHOLD: 0.1,  // 10% changes trigger incremental backup
  FULL_BACKUP_INTERVAL: 3600,  // Full backup every hour (seconds)

  // Integrity checking
  CHECKSUM_ENABLED: true,
  MAGIC_NUMBER: 0x464C4F57,    // 'FLOW' magic number
  VERSION: 1,

  // Performance tuning
  PREFAULT_PAGES: true,        // Pre-fault memory pages
  USE_HUGE_PAGES: false,       // Use huge pages if available
  DIRECT_IO: false,            // Use direct I/O (bypass OS cache)
};

/**
 * File header layout for memory-mapped persistence
 */
const FILE_HEADER_LAYOUT = {
  magic: 0,              // uint32 - Magic number
  version: 4,            // uint32 - Format version
  fileSize: 8,           // uint64 - Total file size
  dataSize: 16,          // uint64 - Active data size
  regionCount: 24,       // uint32 - Number of memory regions
  dirtyRegions: 28,      // uint32 - Number of dirty regions
  lastCheckpoint: 32,    // uint64 - Last checkpoint timestamp
  lastFullBackup: 40,    // uint64 - Last full backup timestamp
  checksumTable: 48,     // uint64 - Offset to checksum table
  metadataOffset: 56,    // uint64 - Offset to metadata region
  reserved: 64           // 960 bytes reserved for future use
};

/**
 * Region metadata layout
 */
const REGION_METADATA_LAYOUT = {
  checksum: 0,           // uint32 - CRC32 checksum
  lastModified: 4,       // uint64 - Last modification timestamp
  writeCount: 12,        // uint32 - Number of writes to this region
  flags: 16,             // uint32 - Region flags (dirty, compressed, etc.)
  reserved: 20           // 12 bytes reserved
};

/**
 * Memory-mapped file persistence manager
 */
export class MemoryMappedPersistence {
  constructor(sharedBuffer, backupPath, config = PERSISTENCE_CONFIG) {
    this.sharedBuffer = sharedBuffer;
    this.backupPath = backupPath;
    this.config = config;

    // Memory region tracking
    this.regionCount = Math.ceil(sharedBuffer.byteLength / config.REGION_SIZE);
    this.dirtyRegions = new Set();
    this.regionChecksums = new Map();

    // File handles and metadata
    this.fileHandle = null;
    this.fileSize = 0;
    this.isInitialized = false;

    // Performance metrics
    this.stats = {
      totalBackups: 0,
      incrementalBackups: 0,
      fullBackups: 0,
      totalSyncTime: 0,
      avgSyncTime: 0,
      regionsSync: 0,
      checksumFailures: 0,
      lastBackupTime: 0
    };

    // Background operations
    this.backgroundSync = null;
    this.checkpointTimer = null;

    // Integrity verification
    this.checksumTable = new Map();
  }

  /**
   * Initialize memory-mapped persistence
   */
  async initialize() {
    try {
      await this.createOrOpenBackupFile();
      await this.initializeFileHeader();
      await this.verifyFileIntegrity();

      this.startBackgroundOperations();
      this.isInitialized = true;

      console.log(`Persistence initialized: ${this.backupPath} (${this.regionCount} regions)`);
    } catch (error) {
      console.error('Failed to initialize persistence:', error);
      throw error;
    }
  }

  /**
   * Create or open backup file
   */
  async createOrOpenBackupFile() {
    const totalFileSize = this.config.HEADER_SIZE +
                         (this.regionCount * this.config.REGION_SIZE) +
                         (this.regionCount * 32); // Metadata per region

    try {
      // Try to open existing file
      const stats = await fs.stat(this.backupPath);
      this.fileSize = stats.size;

      if (this.fileSize < totalFileSize) {
        // File is too small, extend it
        await this.extendFile(totalFileSize);
      }
    } catch (error) {
      if (error.code === 'ENOENT') {
        // File doesn't exist, create it
        await this.createNewBackupFile(totalFileSize);
      } else {
        throw error;
      }
    }

    // Open file handle for memory mapping
    this.fileHandle = await fs.open(this.backupPath, 'r+');
  }

  /**
   * Create new backup file with proper structure
   */
  async createNewBackupFile(totalFileSize) {
    this.fileSize = totalFileSize;

    // Create file and allocate space
    const fileHandle = await fs.open(this.backupPath, 'w+');

    try {
      // Pre-allocate file space
      await fileHandle.truncate(totalFileSize);

      // Initialize with zeros (optional, but ensures consistent state)
      const zeroChunk = Buffer.alloc(64 * 1024, 0); // 64KB zero buffer
      let written = 0;

      while (written < totalFileSize) {
        const chunkSize = Math.min(zeroChunk.length, totalFileSize - written);
        await fileHandle.write(zeroChunk, 0, chunkSize, written);
        written += chunkSize;
      }

      await fileHandle.sync();
    } finally {
      await fileHandle.close();
    }

    console.log(`Created new backup file: ${this.backupPath} (${totalFileSize} bytes)`);
  }

  /**
   * Extend existing file to accommodate larger shared buffer
   */
  async extendFile(newSize) {
    if (this.fileHandle) {
      await this.fileHandle.truncate(newSize);
      await this.fileHandle.sync();
      this.fileSize = newSize;
      console.log(`Extended backup file to ${newSize} bytes`);
    }
  }

  /**
   * Initialize file header with metadata
   */
  async initializeFileHeader() {
    const headerBuffer = Buffer.alloc(this.config.HEADER_SIZE);
    const headerView = new DataView(headerBuffer.buffer);

    // Write header fields
    headerView.setUint32(FILE_HEADER_LAYOUT.magic, this.config.MAGIC_NUMBER, true);
    headerView.setUint32(FILE_HEADER_LAYOUT.version, this.config.VERSION, true);
    headerView.setBigUint64(FILE_HEADER_LAYOUT.fileSize, BigInt(this.fileSize), true);
    headerView.setBigUint64(FILE_HEADER_LAYOUT.dataSize, BigInt(this.sharedBuffer.byteLength), true);
    headerView.setUint32(FILE_HEADER_LAYOUT.regionCount, this.regionCount, true);
    headerView.setUint32(FILE_HEADER_LAYOUT.dirtyRegions, 0, true);
    headerView.setBigUint64(FILE_HEADER_LAYOUT.lastCheckpoint, BigInt(Date.now()), true);
    headerView.setBigUint64(FILE_HEADER_LAYOUT.lastFullBackup, BigInt(0), true);

    // Calculate offsets
    const checksumTableOffset = this.config.HEADER_SIZE +
                               (this.regionCount * this.config.REGION_SIZE);
    const metadataOffset = checksumTableOffset + (this.regionCount * 4); // 4 bytes per checksum

    headerView.setBigUint64(FILE_HEADER_LAYOUT.checksumTable, BigInt(checksumTableOffset), true);
    headerView.setBigUint64(FILE_HEADER_LAYOUT.metadataOffset, BigInt(metadataOffset), true);

    // Write header to file
    await this.fileHandle.write(headerBuffer, 0, this.config.HEADER_SIZE, 0);
    await this.fileHandle.sync();
  }

  /**
   * Verify file integrity on startup
   */
  async verifyFileIntegrity() {
    // Read and verify header
    const headerBuffer = Buffer.alloc(this.config.HEADER_SIZE);
    await this.fileHandle.read(headerBuffer, 0, this.config.HEADER_SIZE, 0);

    const headerView = new DataView(headerBuffer.buffer);
    const magic = headerView.getUint32(FILE_HEADER_LAYOUT.magic, true);
    const version = headerView.getUint32(FILE_HEADER_LAYOUT.version, true);

    if (magic !== this.config.MAGIC_NUMBER) {
      throw new Error(`Invalid magic number: expected ${this.config.MAGIC_NUMBER}, got ${magic}`);
    }

    if (version !== this.config.VERSION) {
      throw new Error(`Unsupported version: expected ${this.config.VERSION}, got ${version}`);
    }

    // Load and verify checksums if enabled
    if (this.config.CHECKSUM_ENABLED) {
      await this.loadAndVerifyChecksums();
    }

    console.log('File integrity verification completed successfully');
  }

  /**
   * Load and verify region checksums
   */
  async loadAndVerifyChecksums() {
    const checksumTableOffset = Number(
      (await this.readFileHeader()).checksumTable
    );

    const checksumBuffer = Buffer.alloc(this.regionCount * 4);
    await this.fileHandle.read(
      checksumBuffer, 0, checksumBuffer.length, checksumTableOffset
    );

    const checksumView = new DataView(checksumBuffer.buffer);
    let corruptRegions = 0;

    for (let i = 0; i < this.regionCount; i++) {
      const storedChecksum = checksumView.getUint32(i * 4, true);
      if (storedChecksum !== 0) {
        const regionOffset = this.config.HEADER_SIZE + (i * this.config.REGION_SIZE);
        const actualChecksum = await this.calculateRegionChecksum(i, regionOffset);

        if (storedChecksum !== actualChecksum) {
          console.warn(`Checksum mismatch in region ${i}: expected ${storedChecksum}, got ${actualChecksum}`);
          corruptRegions++;
        } else {
          this.checksumTable.set(i, storedChecksum);
        }
      }
    }

    if (corruptRegions > 0) {
      console.warn(`Found ${corruptRegions} corrupt regions during verification`);
      this.stats.checksumFailures += corruptRegions;
    }
  }

  /**
   * Perform incremental backup of dirty regions
   */
  async incrementalBackup() {
    if (this.dirtyRegions.size === 0) {
      return { backedUpRegions: 0, duration: 0 };
    }

    const startTime = performance.now();
    const regionsToSync = Array.from(this.dirtyRegions);
    let syncedRegions = 0;

    try {
      // Process regions in batches for better I/O performance
      for (let i = 0; i < regionsToSync.length; i += this.config.SYNC_BATCH_SIZE) {
        const batch = regionsToSync.slice(i, i + this.config.SYNC_BATCH_SIZE);
        await this.syncRegionBatch(batch);
        syncedRegions += batch.length;
      }

      // Update checksums if enabled
      if (this.config.CHECKSUM_ENABLED) {
        await this.updateRegionChecksums(regionsToSync);
      }

      // Update header
      await this.updateBackupHeader();

      // Clear dirty flags
      for (const regionIndex of regionsToSync) {
        this.dirtyRegions.delete(regionIndex);
      }

      const duration = performance.now() - startTime;
      this.updateBackupStats('incremental', syncedRegions, duration);

      return { backedUpRegions: syncedRegions, duration };
    } catch (error) {
      console.error('Incremental backup failed:', error);
      throw error;
    }
  }

  /**
   * Perform full backup of entire shared buffer
   */
  async fullBackup() {
    const startTime = performance.now();

    try {
      // Copy entire shared buffer to file
      const bufferView = new Uint8Array(this.sharedBuffer);
      const buffer = Buffer.from(bufferView);

      await this.fileHandle.write(
        buffer, 0, buffer.length, this.config.HEADER_SIZE
      );

      // Recalculate all checksums
      if (this.config.CHECKSUM_ENABLED) {
        await this.recalculateAllChecksums();
      }

      // Update header with full backup timestamp
      await this.updateBackupHeader(true);

      // Clear all dirty regions
      this.dirtyRegions.clear();

      const duration = performance.now() - startTime;
      this.updateBackupStats('full', this.regionCount, duration);

      return { backedUpRegions: this.regionCount, duration };
    } catch (error) {
      console.error('Full backup failed:', error);
      throw error;
    }
  }

  /**
   * Sync a batch of regions to file
   */
  async syncRegionBatch(regionIndices) {
    const operations = regionIndices.map(async (regionIndex) => {
      const regionOffset = regionIndex * this.config.REGION_SIZE;
      const fileOffset = this.config.HEADER_SIZE + regionOffset;
      const regionSize = Math.min(
        this.config.REGION_SIZE,
        this.sharedBuffer.byteLength - regionOffset
      );

      // Create buffer from SharedArrayBuffer region
      const regionView = new Uint8Array(
        this.sharedBuffer, regionOffset, regionSize
      );
      const regionBuffer = Buffer.from(regionView);

      // Write region to file
      await this.fileHandle.write(regionBuffer, 0, regionSize, fileOffset);
    });

    // Execute all operations in parallel
    await Promise.all(operations);

    // Force sync to disk
    await this.fileHandle.sync();
  }

  /**
   * Update checksums for specified regions
   */
  async updateRegionChecksums(regionIndices) {
    const checksumUpdates = regionIndices.map(async (regionIndex) => {
      const regionOffset = this.config.HEADER_SIZE +
                          (regionIndex * this.config.REGION_SIZE);
      const checksum = await this.calculateRegionChecksum(regionIndex, regionOffset);
      this.checksumTable.set(regionIndex, checksum);
      return { regionIndex, checksum };
    });

    const results = await Promise.all(checksumUpdates);

    // Write updated checksums to file
    const checksumTableOffset = Number(
      (await this.readFileHeader()).checksumTable
    );

    for (const { regionIndex, checksum } of results) {
      const checksumBuffer = Buffer.allocUnsafe(4);
      checksumBuffer.writeUInt32LE(checksum, 0);

      await this.fileHandle.write(
        checksumBuffer, 0, 4, checksumTableOffset + (regionIndex * 4)
      );
    }
  }

  /**
   * Calculate CRC32 checksum for a region
   */
  async calculateRegionChecksum(regionIndex, fileOffset) {
    const regionSize = Math.min(
      this.config.REGION_SIZE,
      this.sharedBuffer.byteLength - (regionIndex * this.config.REGION_SIZE)
    );

    // Read region data from file (for verification) or SharedArrayBuffer (for update)
    let regionData;
    if (fileOffset) {
      const buffer = Buffer.alloc(regionSize);
      await this.fileHandle.read(buffer, 0, regionSize, fileOffset);
      regionData = new Uint8Array(buffer);
    } else {
      const regionOffset = regionIndex * this.config.REGION_SIZE;
      regionData = new Uint8Array(this.sharedBuffer, regionOffset, regionSize);
    }

    return this.crc32(regionData);
  }

  /**
   * Recalculate checksums for all regions
   */
  async recalculateAllChecksums() {
    this.checksumTable.clear();

    const checksumPromises = Array.from({ length: this.regionCount }, (_, i) =>
      this.calculateRegionChecksum(i, null)
    );

    const checksums = await Promise.all(checksumPromises);

    // Update checksum table
    checksums.forEach((checksum, index) => {
      this.checksumTable.set(index, checksum);
    });

    // Write entire checksum table to file
    const checksumTableOffset = Number(
      (await this.readFileHeader()).checksumTable
    );

    const checksumBuffer = Buffer.alloc(this.regionCount * 4);
    const checksumView = new DataView(checksumBuffer.buffer);

    checksums.forEach((checksum, index) => {
      checksumView.setUint32(index * 4, checksum, true);
    });

    await this.fileHandle.write(
      checksumBuffer, 0, checksumBuffer.length, checksumTableOffset
    );
  }

  /**
   * Update backup header with latest metadata
   */
  async updateBackupHeader(isFullBackup = false) {
    const headerBuffer = Buffer.alloc(64); // Partial header update
    const headerView = new DataView(headerBuffer.buffer);

    const now = BigInt(Date.now());
    headerView.setUint32(0, this.dirtyRegions.size, true); // dirty regions
    headerView.setBigUint64(8, now, true); // last checkpoint

    if (isFullBackup) {
      headerView.setBigUint64(16, now, true); // last full backup
    }

    await this.fileHandle.write(
      headerBuffer, 0, isFullBackup ? 24 : 16,
      FILE_HEADER_LAYOUT.dirtyRegions
    );
  }

  /**
   * Read file header for metadata
   */
  async readFileHeader() {
    const headerBuffer = Buffer.alloc(this.config.HEADER_SIZE);
    await this.fileHandle.read(headerBuffer, 0, this.config.HEADER_SIZE, 0);

    const headerView = new DataView(headerBuffer.buffer);

    return {
      magic: headerView.getUint32(FILE_HEADER_LAYOUT.magic, true),
      version: headerView.getUint32(FILE_HEADER_LAYOUT.version, true),
      fileSize: headerView.getBigUint64(FILE_HEADER_LAYOUT.fileSize, true),
      dataSize: headerView.getBigUint64(FILE_HEADER_LAYOUT.dataSize, true),
      regionCount: headerView.getUint32(FILE_HEADER_LAYOUT.regionCount, true),
      dirtyRegions: headerView.getUint32(FILE_HEADER_LAYOUT.dirtyRegions, true),
      lastCheckpoint: headerView.getBigUint64(FILE_HEADER_LAYOUT.lastCheckpoint, true),
      lastFullBackup: headerView.getBigUint64(FILE_HEADER_LAYOUT.lastFullBackup, true),
      checksumTable: headerView.getBigUint64(FILE_HEADER_LAYOUT.checksumTable, true),
      metadataOffset: headerView.getBigUint64(FILE_HEADER_LAYOUT.metadataOffset, true)
    };
  }

  /**
   * Restore shared buffer from backup file
   */
  async restoreFromBackup() {
    if (!this.isInitialized) {
      await this.initialize();
    }

    const startTime = performance.now();

    try {
      // Verify file integrity before restore
      await this.verifyFileIntegrity();

      // Read data from file to shared buffer
      const dataBuffer = Buffer.alloc(this.sharedBuffer.byteLength);
      await this.fileHandle.read(
        dataBuffer, 0, dataBuffer.length, this.config.HEADER_SIZE
      );

      // Copy to SharedArrayBuffer
      const bufferView = new Uint8Array(this.sharedBuffer);
      bufferView.set(dataBuffer);

      // Clear dirty regions after successful restore
      this.dirtyRegions.clear();

      const duration = performance.now() - startTime;
      console.log(`Restore completed in ${duration.toFixed(2)}ms`);

      return { success: true, duration, restoredBytes: dataBuffer.length };
    } catch (error) {
      console.error('Restore failed:', error);
      return { success: false, error: error.message, duration: 0 };
    }
  }

  /**
   * Mark region as dirty for next backup
   */
  markRegionDirty(offset) {
    const regionIndex = Math.floor(offset / this.config.REGION_SIZE);
    this.dirtyRegions.add(regionIndex);
  }

  /**
   * Start background persistence operations
   */
  startBackgroundOperations() {
    // Periodic checkpoints
    this.checkpointTimer = setInterval(async () => {
      if (this.dirtyRegions.size > 0) {
        try {
          await this.incrementalBackup();
        } catch (error) {
          console.error('Background checkpoint failed:', error);
        }
      }
    }, this.config.CHECKPOINT_INTERVAL);

    // Periodic full backups
    setInterval(async () => {
      try {
        await this.fullBackup();
        console.log('Scheduled full backup completed');
      } catch (error) {
        console.error('Scheduled full backup failed:', error);
      }
    }, this.config.FULL_BACKUP_INTERVAL * 1000);
  }

  /**
   * Stop background operations
   */
  stopBackgroundOperations() {
    if (this.checkpointTimer) {
      clearInterval(this.checkpointTimer);
      this.checkpointTimer = null;
    }
  }

  /**
   * Graceful shutdown with final backup
   */
  async shutdown() {
    console.log('Shutting down persistence layer...');

    // Stop background operations
    this.stopBackgroundOperations();

    // Perform final incremental backup
    if (this.dirtyRegions.size > 0) {
      await this.incrementalBackup();
    }

    // Close file handle
    if (this.fileHandle) {
      await this.fileHandle.close();
      this.fileHandle = null;
    }

    console.log('Persistence shutdown completed');
  }

  /**
   * Update backup statistics
   */
  updateBackupStats(type, regionCount, duration) {
    this.stats.totalBackups++;
    this.stats.regionsSync += regionCount;
    this.stats.totalSyncTime += duration;
    this.stats.avgSyncTime = this.stats.totalSyncTime / this.stats.totalBackups;
    this.stats.lastBackupTime = Date.now();

    if (type === 'incremental') {
      this.stats.incrementalBackups++;
    } else if (type === 'full') {
      this.stats.fullBackups++;
    }
  }

  /**
   * Get persistence statistics
   */
  getStats() {
    return {
      ...this.stats,
      dirtyRegions: this.dirtyRegions.size,
      totalRegions: this.regionCount,
      fileSize: this.fileSize,
      isInitialized: this.isInitialized,
      checksumTableSize: this.checksumTable.size
    };
  }

  /**
   * CRC32 checksum implementation
   */
  crc32(data) {
    const crcTable = this.getCrcTable();
    let crc = 0xFFFFFFFF;

    for (let i = 0; i < data.length; i++) {
      crc = crcTable[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
    }

    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  /**
   * Generate CRC32 lookup table
   */
  getCrcTable() {
    if (!this._crcTable) {
      this._crcTable = new Array(256);

      for (let i = 0; i < 256; i++) {
        let crc = i;
        for (let j = 0; j < 8; j++) {
          crc = (crc & 1) ? (0xEDB88320 ^ (crc >>> 1)) : (crc >>> 1);
        }
        this._crcTable[i] = crc;
      }
    }

    return this._crcTable;
  }
}

/**
 * Backup strategy manager for coordinating different backup approaches
 */
export class BackupStrategyManager {
  constructor(persistence) {
    this.persistence = persistence;
    this.strategies = new Map();
    this.currentStrategy = 'adaptive';

    this.initializeStrategies();
  }

  /**
   * Initialize available backup strategies
   */
  initializeStrategies() {
    // Aggressive strategy - frequent incremental backups
    this.strategies.set('aggressive', {
      incrementalInterval: 1000,    // 1 second
      fullBackupInterval: 1800,     // 30 minutes
      dirtyThreshold: 0.05,         // 5% changes
      priority: 'consistency'
    });

    // Balanced strategy - moderate backup frequency
    this.strategies.set('balanced', {
      incrementalInterval: 5000,    // 5 seconds
      fullBackupInterval: 3600,     // 1 hour
      dirtyThreshold: 0.1,          // 10% changes
      priority: 'balance'
    });

    // Performance strategy - minimize I/O impact
    this.strategies.set('performance', {
      incrementalInterval: 15000,   // 15 seconds
      fullBackupInterval: 7200,     // 2 hours
      dirtyThreshold: 0.2,          // 20% changes
      priority: 'performance'
    });

    // Adaptive strategy - adjust based on workload
    this.strategies.set('adaptive', {
      incrementalInterval: 5000,    // Base: 5 seconds
      fullBackupInterval: 3600,     // Base: 1 hour
      dirtyThreshold: 0.1,          // Base: 10% changes
      priority: 'adaptive'
    });
  }

  /**
   * Select optimal backup strategy based on workload characteristics
   */
  selectStrategy(workloadMetrics) {
    const {
      writeRate,      // Writes per second
      dirtyRatio,     // Percentage of dirty regions
      memoryPressure, // Memory utilization
      ioLatency       // Average I/O latency
    } = workloadMetrics;

    let selectedStrategy = 'balanced';

    if (writeRate > 1000 && dirtyRatio > 0.3) {
      // High write rate with lots of changes - use aggressive
      selectedStrategy = 'aggressive';
    } else if (writeRate < 100 && memoryPressure < 0.5) {
      // Low write rate with plenty of memory - use performance
      selectedStrategy = 'performance';
    } else if (ioLatency > 50) {
      // High I/O latency - minimize backup frequency
      selectedStrategy = 'performance';
    } else {
      // Use adaptive strategy to adjust dynamically
      selectedStrategy = 'adaptive';
    }

    if (selectedStrategy !== this.currentStrategy) {
      this.switchStrategy(selectedStrategy);
    }

    return selectedStrategy;
  }

  /**
   * Switch to different backup strategy
   */
  switchStrategy(strategyName) {
    if (!this.strategies.has(strategyName)) {
      throw new Error(`Unknown backup strategy: ${strategyName}`);
    }

    console.log(`Switching backup strategy: ${this.currentStrategy} -> ${strategyName}`);
    this.currentStrategy = strategyName;

    // Reconfigure persistence based on new strategy
    const strategy = this.strategies.get(strategyName);
    this.persistence.config.CHECKPOINT_INTERVAL = strategy.incrementalInterval;
    this.persistence.config.FULL_BACKUP_INTERVAL = strategy.fullBackupInterval;
    this.persistence.config.INCREMENTAL_THRESHOLD = strategy.dirtyThreshold;
  }

  /**
   * Get current strategy configuration
   */
  getCurrentStrategy() {
    return {
      name: this.currentStrategy,
      config: this.strategies.get(this.currentStrategy)
    };
  }
}

export { PERSISTENCE_CONFIG, FILE_HEADER_LAYOUT };