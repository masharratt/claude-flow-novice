/**
 * Fallback Memory System - SQLite-Independent Implementation
 *
 * Provides robust memory functionality without external dependencies.
 * Falls back gracefully when SQLite is unavailable, maintaining
 * full functionality for Byzantine consensus validation.
 *
 * Critical for Phase 1 completion validation framework.
 *
 * @module fallback-memory-system
 */

import { EventEmitter } from 'events';
import { performance } from 'perf_hooks';
import fs from 'fs/promises';
import path from 'path';

/**
 * In-Memory Storage Engine - Zero Dependencies
 * Provides SQLite-like functionality without external dependencies
 */
class InMemoryStorageEngine extends EventEmitter {
  constructor(options = {}) {
    super();

    this.options = {
      maxMemoryMB: options.maxMemoryMB || 100,
      compressionThreshold: options.compressionThreshold || 10240,
      gcInterval: options.gcInterval || 60000, // 1 minute
      persistFile: options.persistFile || '.fallback-memory.json',
      enablePersistence: options.enablePersistence !== false,
      ...options
    };

    // Core storage structures
    this.storage = new Map();
    this.namespaces = new Map();
    this.metadata = new Map();
    this.stats = {
      totalEntries: 0,
      memoryUsage: 0,
      operations: {
        store: 0,
        retrieve: 0,
        delete: 0,
        search: 0
      },
      lastGC: Date.now()
    };

    // Performance tracking
    this.metrics = new Map();
    this.gcTimer = null;
    this.isInitialized = false;

    // Byzantine consensus support
    this.truthScoring = new Map();
    this.validationHistory = [];
    this.consensusState = {
      agreements: 0,
      disagreements: 0,
      accuracy: 0
    };

    this.startGarbageCollection();
  }

  /**
   * Initialize the fallback memory system
   */
  async initialize() {
    if (this.isInitialized) return;

    const startTime = performance.now();

    try {
      // Try to restore from persistent storage
      if (this.options.enablePersistence) {
        await this.restoreFromPersistence();
      }

      this.isInitialized = true;
      const duration = performance.now() - startTime;

      this.recordMetric('initialize', duration);
      this.emit('initialized', {
        mode: 'fallback',
        duration,
        sqliteAvailable: false,
        entriesRestored: this.stats.totalEntries
      });

      console.log(`✅ Fallback Memory System initialized (${duration.toFixed(2)}ms)`);
      console.log(`📊 Restored ${this.stats.totalEntries} entries from persistence`);

      return { success: true, mode: 'fallback', entriesRestored: this.stats.totalEntries };
    } catch (error) {
      this.emit('error', error);
      throw new Error(`Failed to initialize Fallback Memory System: ${error.message}`);
    }
  }

  /**
   * Store a value with full SQLite compatibility
   */
  async store(key, value, options = {}) {
    this.ensureInitialized();

    const startTime = performance.now();
    const namespace = options.namespace || 'default';
    const storageKey = this.getStorageKey(key, namespace);
    const ttl = options.ttl;
    const tags = options.tags || [];
    const metadata = options.metadata || {};

    try {
      // Serialize and compress if needed
      let serializedValue = value;
      let type = 'string';
      let compressed = false;

      if (typeof value !== 'string') {
        serializedValue = JSON.stringify(value);
        type = 'json';
      }

      const size = Buffer.byteLength(serializedValue, 'utf8');

      if (size > this.options.compressionThreshold) {
        // Simple compression simulation - in production use proper compression
        compressed = true;
      }

      // Calculate expiry
      const now = Date.now();
      const expiresAt = ttl ? now + (ttl * 1000) : null;

      // Store entry
      const entry = {
        key,
        namespace,
        value: serializedValue,
        originalValue: value,
        type,
        size,
        compressed,
        tags,
        metadata,
        ttl,
        expiresAt,
        createdAt: now,
        updatedAt: now,
        accessedAt: now,
        accessCount: 1
      };

      const existed = this.storage.has(storageKey);
      if (existed) {
        const oldEntry = this.storage.get(storageKey);
        entry.createdAt = oldEntry.createdAt;
        entry.accessCount = oldEntry.accessCount + 1;
        this.stats.memoryUsage -= oldEntry.size;
      } else {
        this.stats.totalEntries++;
      }

      this.storage.set(storageKey, entry);
      this.stats.memoryUsage += size;
      this.stats.operations.store++;

      // Update namespace tracking
      if (!this.namespaces.has(namespace)) {
        this.namespaces.set(namespace, new Set());
      }
      this.namespaces.get(namespace).add(key);

      // Persist if enabled
      if (this.options.enablePersistence) {
        setImmediate(() => this.persistToStorage());
      }

      const duration = performance.now() - startTime;
      this.recordMetric('store', duration);

      this.emit('stored', {
        key,
        namespace,
        size,
        compressed,
        existed,
        mode: 'fallback'
      });

      return { success: true, key, namespace, size, existed };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Retrieve a value with expiry handling
   */
  async retrieve(key, namespace = 'default') {
    this.ensureInitialized();

    const startTime = performance.now();
    const storageKey = this.getStorageKey(key, namespace);

    try {
      const entry = this.storage.get(storageKey);

      if (!entry) {
        this.recordMetric('retrieve_miss', performance.now() - startTime);
        this.stats.operations.retrieve++;
        return null;
      }

      // Check expiry
      if (entry.expiresAt && entry.expiresAt < Date.now()) {
        this.storage.delete(storageKey);
        this.stats.totalEntries--;
        this.stats.memoryUsage -= entry.size;

        // Update namespace tracking
        const nsKeys = this.namespaces.get(namespace);
        if (nsKeys) {
          nsKeys.delete(key);
          if (nsKeys.size === 0) {
            this.namespaces.delete(namespace);
          }
        }

        this.recordMetric('retrieve_expired', performance.now() - startTime);
        this.stats.operations.retrieve++;
        return null;
      }

      // Update access stats
      entry.accessedAt = Date.now();
      entry.accessCount++;

      const duration = performance.now() - startTime;
      this.recordMetric('retrieve_hit', duration);
      this.stats.operations.retrieve++;

      return entry.originalValue;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * List entries in a namespace
   */
  async list(namespace = 'default', options = {}) {
    this.ensureInitialized();

    const limit = options.limit || 100;
    const offset = options.offset || 0;
    const entries = [];

    try {
      for (const [storageKey, entry] of this.storage.entries()) {
        if (entry.namespace === namespace) {
          // Check expiry
          if (entry.expiresAt && entry.expiresAt < Date.now()) {
            this.storage.delete(storageKey);
            continue;
          }

          entries.push({
            key: entry.key,
            namespace: entry.namespace,
            type: entry.type,
            size: entry.size,
            compressed: entry.compressed,
            tags: entry.tags,
            createdAt: new Date(entry.createdAt),
            updatedAt: new Date(entry.updatedAt),
            accessedAt: new Date(entry.accessedAt),
            accessCount: entry.accessCount,
            expiresAt: entry.expiresAt ? new Date(entry.expiresAt) : null
          });
        }
      }

      // Sort by access time
      entries.sort((a, b) => b.accessedAt.getTime() - a.accessedAt.getTime());

      // Apply pagination
      const paginatedEntries = entries.slice(offset, offset + limit);

      return paginatedEntries;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Delete an entry
   */
  async delete(key, namespace = 'default') {
    this.ensureInitialized();

    const storageKey = this.getStorageKey(key, namespace);
    const entry = this.storage.get(storageKey);

    if (!entry) {
      return false;
    }

    try {
      this.storage.delete(storageKey);
      this.stats.totalEntries--;
      this.stats.memoryUsage -= entry.size;
      this.stats.operations.delete++;

      // Update namespace tracking
      const nsKeys = this.namespaces.get(namespace);
      if (nsKeys) {
        nsKeys.delete(key);
        if (nsKeys.size === 0) {
          this.namespaces.delete(namespace);
        }
      }

      // Persist if enabled
      if (this.options.enablePersistence) {
        setImmediate(() => this.persistToStorage());
      }

      this.emit('deleted', { key, namespace, mode: 'fallback' });
      return true;
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Clear all entries in a namespace
   */
  async clear(namespace = 'default') {
    this.ensureInitialized();

    let cleared = 0;
    const toDelete = [];

    try {
      for (const [storageKey, entry] of this.storage.entries()) {
        if (entry.namespace === namespace) {
          toDelete.push({ storageKey, entry });
        }
      }

      for (const { storageKey, entry } of toDelete) {
        this.storage.delete(storageKey);
        this.stats.memoryUsage -= entry.size;
        cleared++;
      }

      this.stats.totalEntries -= cleared;
      this.namespaces.delete(namespace);

      // Persist if enabled
      if (this.options.enablePersistence) {
        setImmediate(() => this.persistToStorage());
      }

      this.emit('cleared', { namespace, count: cleared, mode: 'fallback' });
      return { cleared };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Search entries by pattern or tags
   */
  async search(options = {}) {
    this.ensureInitialized();

    const { pattern, namespace, tags, limit = 50, offset = 0 } = options;
    const results = [];

    try {
      for (const [storageKey, entry] of this.storage.entries()) {
        let match = true;

        // Namespace filter
        if (namespace && entry.namespace !== namespace) {
          match = false;
        }

        // Pattern filter
        if (match && pattern) {
          match = entry.key.includes(pattern);
        }

        // Tags filter
        if (match && tags && tags.length > 0) {
          const entryTags = entry.tags || [];
          match = tags.some(tag => entryTags.includes(tag));
        }

        // Expiry check
        if (match && entry.expiresAt && entry.expiresAt < Date.now()) {
          this.storage.delete(storageKey);
          match = false;
        }

        if (match) {
          results.push({
            key: entry.key,
            namespace: entry.namespace,
            value: entry.originalValue,
            metadata: entry.metadata,
            tags: entry.tags
          });
        }
      }

      this.stats.operations.search++;

      // Apply pagination
      return results.slice(offset, offset + limit);
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Get comprehensive statistics
   */
  async getStats() {
    this.ensureInitialized();

    const namespaceStats = {};

    for (const [namespace, keys] of this.namespaces.entries()) {
      let totalSize = 0;
      let compressedCount = 0;

      for (const key of keys) {
        const storageKey = this.getStorageKey(key, namespace);
        const entry = this.storage.get(storageKey);
        if (entry) {
          totalSize += entry.size;
          if (entry.compressed) compressedCount++;
        }
      }

      namespaceStats[namespace] = {
        count: keys.size,
        totalSize,
        avgSize: keys.size > 0 ? totalSize / keys.size : 0,
        compressed: compressedCount
      };
    }

    return {
      mode: 'fallback',
      sqliteAvailable: false,
      namespaces: namespaceStats,
      database: {
        totalEntries: this.stats.totalEntries,
        totalSize: this.stats.memoryUsage,
        memoryUsageMB: this.stats.memoryUsage / (1024 * 1024)
      },
      operations: { ...this.stats.operations },
      metrics: this.getMetricsSummary(),
      consensus: { ...this.consensusState },
      performance: {
        gcInterval: this.options.gcInterval,
        lastGC: new Date(this.stats.lastGC).toISOString()
      }
    };
  }

  /**
   * Byzantine Consensus Truth Scoring
   */
  async recordTruthScore(key, score, evidence = {}) {
    this.ensureInitialized();

    const truthKey = `truth:${key}`;
    const truthData = {
      score,
      evidence,
      timestamp: Date.now(),
      validator: 'fallback-memory'
    };

    this.truthScoring.set(truthKey, truthData);
    this.validationHistory.push(truthData);

    // Update consensus state
    if (score >= 0.85) {
      this.consensusState.agreements++;
    } else {
      this.consensusState.disagreements++;
    }

    const total = this.consensusState.agreements + this.consensusState.disagreements;
    this.consensusState.accuracy = total > 0 ? this.consensusState.agreements / total : 0;

    return { recorded: true, consensusAccuracy: this.consensusState.accuracy };
  }

  /**
   * Get truth scoring data
   */
  async getTruthScores(keyPattern = null) {
    this.ensureInitialized();

    const scores = [];

    for (const [truthKey, truthData] of this.truthScoring.entries()) {
      if (!keyPattern || truthKey.includes(keyPattern)) {
        scores.push({
          key: truthKey.replace('truth:', ''),
          ...truthData
        });
      }
    }

    return {
      scores,
      consensus: { ...this.consensusState },
      validationCount: this.validationHistory.length
    };
  }

  /**
   * Backup functionality (JSON-based)
   */
  async backup(filepath) {
    this.ensureInitialized();

    try {
      const backupData = {
        metadata: {
          version: '1.0.0',
          mode: 'fallback',
          timestamp: Date.now(),
          totalEntries: this.stats.totalEntries
        },
        storage: Array.from(this.storage.entries()),
        namespaces: Array.from(this.namespaces.entries()).map(([ns, keys]) => [ns, Array.from(keys)]),
        stats: this.stats,
        truthScoring: Array.from(this.truthScoring.entries()),
        consensusState: this.consensusState
      };

      await fs.writeFile(filepath, JSON.stringify(backupData, null, 2), 'utf8');

      this.emit('backup', { filepath, mode: 'fallback' });
      return { success: true, filepath, mode: 'fallback' };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Restore from backup
   */
  async restore(filepath) {
    this.ensureInitialized();

    try {
      const backupData = JSON.parse(await fs.readFile(filepath, 'utf8'));

      // Clear current data
      this.storage.clear();
      this.namespaces.clear();
      this.truthScoring.clear();

      // Restore storage
      for (const [key, entry] of backupData.storage) {
        this.storage.set(key, entry);
      }

      // Restore namespaces
      for (const [ns, keys] of backupData.namespaces) {
        this.namespaces.set(ns, new Set(keys));
      }

      // Restore truth scoring
      for (const [key, data] of backupData.truthScoring) {
        this.truthScoring.set(key, data);
      }

      // Restore stats and consensus
      this.stats = { ...this.stats, ...backupData.stats };
      this.consensusState = { ...backupData.consensusState };

      this.emit('restored', {
        filepath,
        mode: 'fallback',
        entriesRestored: this.stats.totalEntries
      });

      return {
        success: true,
        filepath,
        mode: 'fallback',
        entriesRestored: this.stats.totalEntries
      };
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Close the memory system
   */
  async close() {
    if (!this.isInitialized) return;

    try {
      // Stop garbage collection
      if (this.gcTimer) {
        clearInterval(this.gcTimer);
        this.gcTimer = null;
      }

      // Final persistence
      if (this.options.enablePersistence) {
        await this.persistToStorage();
      }

      // Clear all data
      this.storage.clear();
      this.namespaces.clear();
      this.truthScoring.clear();
      this.validationHistory.length = 0;

      this.isInitialized = false;

      this.emit('closed', { mode: 'fallback' });

      console.log('✅ Fallback Memory System closed successfully');
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  // Private helper methods
  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('Fallback Memory System not initialized. Call initialize() first.');
    }
  }

  getStorageKey(key, namespace) {
    return `${namespace}:${key}`;
  }

  recordMetric(operation, duration) {
    if (!this.metrics.has(operation)) {
      this.metrics.set(operation, []);
    }

    const measurements = this.metrics.get(operation);
    measurements.push(duration);

    // Keep only last 100 measurements
    if (measurements.length > 100) {
      measurements.shift();
    }
  }

  getMetricsSummary() {
    const summary = {};

    for (const [operation, measurements] of this.metrics.entries()) {
      if (measurements.length > 0) {
        summary[operation] = {
          count: measurements.length,
          avg: measurements.reduce((a, b) => a + b, 0) / measurements.length,
          min: Math.min(...measurements),
          max: Math.max(...measurements)
        };
      }
    }

    return summary;
  }

  startGarbageCollection() {
    this.gcTimer = setInterval(() => {
      this.runGarbageCollection();
    }, this.options.gcInterval);
  }

  runGarbageCollection() {
    const now = Date.now();
    let expired = 0;

    try {
      for (const [storageKey, entry] of this.storage.entries()) {
        if (entry.expiresAt && entry.expiresAt < now) {
          this.storage.delete(storageKey);
          this.stats.totalEntries--;
          this.stats.memoryUsage -= entry.size;
          expired++;

          // Update namespace tracking
          const nsKeys = this.namespaces.get(entry.namespace);
          if (nsKeys) {
            nsKeys.delete(entry.key);
            if (nsKeys.size === 0) {
              this.namespaces.delete(entry.namespace);
            }
          }
        }
      }

      this.stats.lastGC = now;

      if (expired > 0) {
        this.emit('gc', { expired, mode: 'fallback' });
      }
    } catch (error) {
      this.emit('error', error);
    }
  }

  async persistToStorage() {
    if (!this.options.enablePersistence) return;

    try {
      const persistData = {
        timestamp: Date.now(),
        storage: Array.from(this.storage.entries()),
        namespaces: Array.from(this.namespaces.entries()).map(([ns, keys]) => [ns, Array.from(keys)]),
        stats: this.stats,
        truthScoring: Array.from(this.truthScoring.entries()),
        consensusState: this.consensusState
      };

      await fs.writeFile(this.options.persistFile, JSON.stringify(persistData), 'utf8');
    } catch (error) {
      // Silent fail for persistence - don't break main functionality
      console.warn('Failed to persist fallback memory:', error.message);
    }
  }

  async restoreFromPersistence() {
    if (!this.options.enablePersistence) return;

    try {
      const data = await fs.readFile(this.options.persistFile, 'utf8');
      const persistData = JSON.parse(data);

      // Restore storage
      for (const [key, entry] of persistData.storage) {
        this.storage.set(key, entry);
      }

      // Restore namespaces
      for (const [ns, keys] of persistData.namespaces) {
        this.namespaces.set(ns, new Set(keys));
      }

      // Restore truth scoring
      if (persistData.truthScoring) {
        for (const [key, data] of persistData.truthScoring) {
          this.truthScoring.set(key, data);
        }
      }

      // Restore stats and consensus
      this.stats = { ...this.stats, ...persistData.stats };
      if (persistData.consensusState) {
        this.consensusState = { ...persistData.consensusState };
      }

      console.log(`📦 Restored ${this.stats.totalEntries} entries from persistence`);
    } catch (error) {
      // Silent fail for restoration - start fresh if persistence fails
      console.log('🔄 Starting with fresh memory state (no valid persistence file)');
    }
  }
}

/**
 * Resilient Memory System with SQLite Fallback
 * Automatically detects SQLite availability and falls back to in-memory storage
 */
export class ResilientMemorySystem extends EventEmitter {
  constructor(options = {}) {
    super();

    this.options = options;
    this.sqliteEngine = null;
    this.fallbackEngine = null;
    this.activeEngine = null;
    this.mode = 'unknown';
    this.isInitialized = false;
  }

  /**
   * Initialize with automatic SQLite detection and fallback
   */
  async initialize() {
    if (this.isInitialized) return;

    const startTime = performance.now();
    let sqliteAvailable = false;

    try {
      // Try to initialize SQLite first (only if better-sqlite3 is available)
      try {
        // Check if SQLite is available before importing
        await this.testSQLiteAvailability();

        const { SharedMemory } = await import('./shared-memory.js');
        this.sqliteEngine = new SharedMemory(this.options);
        await this.sqliteEngine.initialize();

        this.activeEngine = this.sqliteEngine;
        this.mode = 'sqlite';
        sqliteAvailable = true;

        console.log('✅ SQLite memory system initialized successfully');
      } catch (sqliteError) {
        console.warn('⚠️  SQLite unavailable, falling back to in-memory storage:', sqliteError.message);

        // Initialize fallback system
        this.fallbackEngine = new InMemoryStorageEngine(this.options);
        await this.fallbackEngine.initialize();

        this.activeEngine = this.fallbackEngine;
        this.mode = 'fallback';

        console.log('✅ Fallback memory system initialized successfully');
      }

      // Relay events from active engine
      this.activeEngine.on('error', (error) => this.emit('error', error));
      this.activeEngine.on('stored', (data) => this.emit('stored', data));
      this.activeEngine.on('deleted', (data) => this.emit('deleted', data));
      this.activeEngine.on('cleared', (data) => this.emit('cleared', data));
      this.activeEngine.on('backup', (data) => this.emit('backup', data));
      this.activeEngine.on('restored', (data) => this.emit('restored', data));
      this.activeEngine.on('closed', (data) => this.emit('closed', data));
      this.activeEngine.on('gc', (data) => this.emit('gc', data));

      this.isInitialized = true;
      const duration = performance.now() - startTime;

      this.emit('initialized', {
        mode: this.mode,
        sqliteAvailable,
        duration,
        fallbackReady: true
      });

      return {
        success: true,
        mode: this.mode,
        sqliteAvailable,
        fallbackReady: true,
        duration
      };
    } catch (error) {
      this.emit('error', error);
      throw new Error(`Failed to initialize Resilient Memory System: ${error.message}`);
    }
  }

  // Proxy all methods to active engine
  async store(key, value, options = {}) {
    this.ensureInitialized();
    return await this.activeEngine.store(key, value, options);
  }

  async retrieve(key, namespace = 'default') {
    this.ensureInitialized();
    return await this.activeEngine.retrieve(key, namespace);
  }

  async list(namespace = 'default', options = {}) {
    this.ensureInitialized();
    return await this.activeEngine.list(namespace, options);
  }

  async delete(key, namespace = 'default') {
    this.ensureInitialized();
    return await this.activeEngine.delete(key, namespace);
  }

  async clear(namespace = 'default') {
    this.ensureInitialized();
    return await this.activeEngine.clear(namespace);
  }

  async search(options = {}) {
    this.ensureInitialized();
    return await this.activeEngine.search(options);
  }

  async getStats() {
    this.ensureInitialized();
    const stats = await this.activeEngine.getStats();
    return {
      ...stats,
      system: {
        mode: this.mode,
        sqliteAvailable: this.mode === 'sqlite',
        fallbackActive: this.mode === 'fallback',
        resilient: true
      }
    };
  }

  async backup(filepath) {
    this.ensureInitialized();
    return await this.activeEngine.backup(filepath);
  }

  async close() {
    if (!this.isInitialized) return;

    try {
      if (this.activeEngine) {
        await this.activeEngine.close();
      }

      this.isInitialized = false;
      this.emit('closed', { mode: this.mode });
    } catch (error) {
      this.emit('error', error);
      throw error;
    }
  }

  // Byzantine consensus methods (fallback engine specific)
  async recordTruthScore(key, score, evidence = {}) {
    this.ensureInitialized();

    if (this.mode === 'fallback' && this.fallbackEngine.recordTruthScore) {
      return await this.fallbackEngine.recordTruthScore(key, score, evidence);
    }

    // For SQLite engine, store in regular namespace
    return await this.store(`truth:${key}`, {
      score,
      evidence,
      timestamp: Date.now(),
      validator: this.mode
    }, { namespace: 'validation' });
  }

  async getTruthScores(keyPattern = null) {
    this.ensureInitialized();

    if (this.mode === 'fallback' && this.fallbackEngine.getTruthScores) {
      return await this.fallbackEngine.getTruthScores(keyPattern);
    }

    // For SQLite engine, retrieve from validation namespace
    const entries = await this.search({
      namespace: 'validation',
      pattern: keyPattern ? `truth:${keyPattern}` : 'truth:'
    });

    return {
      scores: entries.map(entry => ({
        key: entry.key.replace('truth:', ''),
        ...entry.value
      })),
      consensus: { agreements: 0, disagreements: 0, accuracy: 0 }, // Basic implementation
      validationCount: entries.length
    };
  }

  // Status and diagnostics
  getSystemInfo() {
    return {
      mode: this.mode,
      sqliteAvailable: this.mode === 'sqlite',
      fallbackActive: this.mode === 'fallback',
      initialized: this.isInitialized,
      resilient: true,
      engine: this.activeEngine?.constructor.name || 'none'
    };
  }

  ensureInitialized() {
    if (!this.isInitialized) {
      throw new Error('Resilient Memory System not initialized. Call initialize() first.');
    }
  }

  async testSQLiteAvailability() {
    try {
      // Try to dynamically import better-sqlite3 to test availability
      await import('better-sqlite3');
      return true;
    } catch (error) {
      throw new Error('SQLite not available: ' + error.message);
    }
  }
}

// Export both engines
export { InMemoryStorageEngine };
export default ResilientMemorySystem;

// Convenience factory function
export function createResilientMemory(options = {}) {
  return new ResilientMemorySystem(options);
}

// Test if SQLite is available without throwing
export async function testSQLiteAvailability() {
  try {
    const { SharedMemory } = await import('./shared-memory.js');
    const testDb = new SharedMemory({
      directory: '.test-sqlite',
      filename: 'test.db'
    });

    await testDb.initialize();
    await testDb.store('test', 'value');
    const retrieved = await testDb.retrieve('test');
    await testDb.close();

    return {
      available: true,
      tested: retrieved === 'value',
      error: null
    };
  } catch (error) {
    return {
      available: false,
      tested: false,
      error: error.message
    };
  }
}