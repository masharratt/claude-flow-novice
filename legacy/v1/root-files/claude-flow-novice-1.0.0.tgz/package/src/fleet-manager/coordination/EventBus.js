/**
 * EventBus - High-throughput event routing system
 *
 * Features:
 * - 10,000+ events/second throughput
 * - Multiple routing strategies
 * - Load balancing
 * - Worker thread management
 *
 * @module fleet-manager/coordination
 * @version 2.0.0
 */

export { QEEventBus } from '../../eventbus/QEEventBus.js';
export default QEEventBus;
