// command-registry.js - Extensible command registration system
import process from 'process';
import { initCommand } from './simple-commands/init/index.js';
import { memoryCommand } from './simple-commands/memory.js';
import { memoryConsolidationCommand } from './simple-commands/memory-consolidation.js';
import { sparcCommand } from './simple-commands/sparc.js';
import { agentCommand } from './simple-commands/agent.js';
import { taskCommand } from './simple-commands/task.js';
import { configCommand } from './simple-commands/config.js';
import { statusCommand } from './simple-commands/status.js';
import { mcpCommand } from './simple-commands/mcp.js';
import { monitorCommand } from './simple-commands/monitor.js';
import { startCommand } from './simple-commands/start.js';
import { swarmCommand } from './simple-commands/swarm.js';
import { batchManagerCommand } from './simple-commands/batch-manager.js';
import { githubCommand } from './simple-commands/github.js';
import { trainingAction } from './simple-commands/training.js';
import { analysisAction } from './simple-commands/analysis.js';
import { automationAction } from './simple-commands/automation.js';
import { coordinationAction } from './simple-commands/coordination.js';
import { hooksAction } from './simple-commands/hooks.js';
import { hookSafetyCommand } from './simple-commands/hook-safety.js';
import { hiveMindCommand } from './simple-commands/hive-mind.js';
import { HelpFormatter } from './help-formatter.js';
import hiveMindOptimizeCommand from './simple-commands/hive-mind-optimize.js';
import { neuralCommand } from './simple-commands/neural.js';
import { goalCommand } from './simple-commands/goal.js';
import {
  showUnifiedMetrics,
  fixTaskAttribution,
} from './simple-commands/swarm-metrics-integration.js';
import { migrateHooksCommand, migrateHooksCommandConfig } from './simple-commands/migrate-hooks.js';
import {
  fixHookVariablesCommand,
  fixHookVariablesCommandConfig,
} from './simple-commands/fix-hook-variables.js';
import {
  initializePerformanceTracking,
  trackCommandExecution,
} from './simple-commands/performance-hooks.js';
import { preferencesCommand } from './preferences.js';
import { personalizationCommand } from './personalization-cli.js';
import { handleFrameworkValidationCommand } from './commands/validate-framework.js';
import { hookCommand } from './commands/hook.js';
// Maestro commands integrated with clean implementation
// Note: Maestro TypeScript commands now integrated directly in ./commands/maestro.ts
// Note: TypeScript imports commented out for Node.js compatibility
// import { ruvSwarmAction } from './commands/ruv-swarm.ts';
// import { configIntegrationAction } from './commands/config-integration.ts';

// Command registry for extensible CLI
export const commandRegistry = new Map();

// Register core commands
export function registerCoreCommands() {
  commandRegistry.set('init', {
    handler: initCommand,
    description: 'Initialize Claude Code integration files and SPARC development environment',
    usage: 'init [--force] [--minimal] [--sparc]',
    examples: [
      'npx claude-flow@latest init --sparc  # Recommended: Full SPARC setup',
      'init --sparc                         # Initialize with SPARC modes',
      'init --force --minimal               # Minimal setup, overwrite existing',
      'init --sparc --force                 # Force SPARC setup',
    ],
    details: `
The --sparc flag creates a complete development environment:
  • .roomodes file containing 17 specialized SPARC modes
  • CLAUDE.md for AI-readable project instructions
  • Pre-configured modes: architect, code, tdd, debug, security, and more
  • Ready for TDD workflows and automated code generation
  
First-time users should run: npx claude-flow@latest init --sparc`,
  });

  commandRegistry.set('start', {
    handler: startCommand,
    description: 'Start the Claude-Flow orchestration system',
    usage: 'start [--daemon] [--port <port>] [--verbose] [--ui] [--web]',
    examples: [
      'start                    # Start in interactive mode',
      'start --daemon           # Start as background daemon',
      'start --port 8080        # Use custom MCP port',
      'start --verbose          # Show detailed system activity',
      'start --ui               # Launch terminal-based UI',
      'start --web              # Launch web-based UI',
    ],
  });

  // Add start-ui as a convenient alias for launching the UI
  commandRegistry.set('start-ui', {
    handler: async (args, flags) => {
      // Import and use the direct UI launcher
      const { launchUI } = await import('./simple-commands/start-ui.js');
      // Pass the full raw arguments from process.argv
      const fullArgs = process.argv.slice(3); // Skip node, script, and command
      return launchUI(fullArgs);
    },
    description: 'Start the UI interface (web UI by default)',
    usage: 'start-ui [--port <port>] [--terminal]',
    examples: [
      'start-ui                 # Launch web-based UI (default)',
      'start-ui --port 3000     # Use custom port',
      'start-ui --terminal      # Launch terminal-based UI instead',
    ],
  });

  commandRegistry.set('memory', {
    handler: memoryCommand,
    description: 'Memory management operations',
    usage: 'memory <subcommand> [options]',
    examples: [
      'memory store key "value"',
      'memory query search_term',
      'memory stats',
      'memory export backup.json',
    ],
  });

  commandRegistry.set('memory-consolidate', {
    handler: memoryConsolidationCommand,
    description: 'Consolidate fragmented memory stores into unified database',
    usage: 'memory-consolidate <command> [options]',
    examples: [
      'memory-consolidate scan                # Scan for all memory stores',
      'memory-consolidate plan                # Create consolidation plan',
      'memory-consolidate execute --force     # Execute consolidation',
      'memory-consolidate report              # Generate report',
    ],
    details: `
Memory Consolidation Features:
  • Discovers all memory storage locations (JSON & SQLite)
  • Creates automatic backups before consolidation
  • Merges all stores into unified SQLite database
  • Optimizes with indices for better performance
  • Maintains backward compatibility
  
Benefits:
  • Single source of truth for all memory data
  • Improved query performance with indices
  • Reduced disk fragmentation
  • Easier backup and restore
  • Cross-session persistence`,
  });

  commandRegistry.set('sparc', {
    handler: sparcCommand,
    description: 'SPARC development mode operations',
    usage: 'sparc [subcommand] [options]',
    examples: [
      'sparc "orchestrate full app development"  # Default: sparc orchestrator',
      'sparc modes                               # List available modes',
      'sparc run code "implement feature"        # Run specific mode',
      'sparc tdd "feature description"           # TDD workflow',
      'sparc info architect                      # Mode details',
    ],
  });

  // Note: Maestro commands are now handled by TypeScript module
  // See src/cli/commands/maestro.ts for the clean implementation
  commandRegistry.set('maestro', {
    handler: () => {
      console.log('⚠️  Maestro commands have been moved to TypeScript.');
      console.log('Please use: npx claude-flow-novice maestro help');
      console.log('Or import from: ./commands/maestro.js after compilation');
    },
    description: 'Maestro: Specs-Driven Development with Hive Mind Integration',
    usage: 'maestro <subcommand> [options]',
    examples: [
      'maestro create-spec my-feature --request "Implement user auth"',
      'maestro generate-design my-feature',
      'maestro generate-tasks my-feature',
      'maestro implement-task my-feature 1',
      'maestro approve-phase my-feature',
      'maestro status my-feature --detailed',
      'maestro init-steering api-design',
      'maestro help',
    ],
  });

  commandRegistry.set('agent', {
    handler: agentCommand,
    description: 'Manage AI agents and hierarchies',
    usage: 'agent <subcommand> [options]',
    examples: [
      'agent spawn researcher --name "DataBot"',
      'agent list --verbose',
      'agent hierarchy create enterprise',
      'agent ecosystem status',
    ],
  });

  commandRegistry.set('task', {
    handler: taskCommand,
    description: 'Manage tasks and workflows',
    usage: 'task <subcommand> [options]',
    examples: [
      'task create research "Market analysis"',
      'task list --filter running',
      'task workflow examples/dev-flow.json',
      'task coordination status',
    ],
  });

  commandRegistry.set('config', {
    handler: configCommand,
    description: 'Manage system configuration',
    usage: 'config <subcommand> [options]',
    examples: [
      'config init',
      'config set terminal.poolSize 15',
      'config get orchestrator.maxConcurrentTasks',
      'config validate',
    ],
  });

  commandRegistry.set('status', {
    handler: statusCommand,
    description: 'Show system status and health',
    usage: 'status [--verbose] [--json]',
    examples: ['status', 'status --verbose', 'status --json'],
  });

  commandRegistry.set('mcp', {
    handler: mcpCommand,
    description: 'Manage MCP server and tools',
    usage: 'mcp <subcommand> [options]',
    examples: ['mcp status', 'mcp start --port 8080', 'mcp tools --verbose', 'mcp auth setup'],
  });

  commandRegistry.set('monitor', {
    handler: monitorCommand,
    description: 'Real-time system monitoring',
    usage: 'monitor [--watch] [--interval <ms>]',
    examples: [
      'monitor',
      'monitor --watch',
      'monitor --interval 1000 --watch',
      'monitor --format json',
    ],
  });

  commandRegistry.set('swarm', {
    handler: swarmCommand,
    description: 'Swarm-based AI agent coordination',
    usage: 'swarm <objective> [options]',
    examples: [
      'swarm "Build a REST API"',
      'swarm "Research cloud architecture" --strategy research',
      'swarm "Analyze data" --max-agents 3 --parallel',
      'swarm "Development task" --ui --monitor --background',
    ],
  });

  // Direct CLI Swarm Execution Interface
  commandRegistry.set('swarm-exec', {
    handler: async (args, flags) => {
      try {
        // Import the swarm-exec CLI module
        const { program } = await import('./commands/swarm-exec.js');
        // Parse arguments and execute
        program.parse(['node', 'swarm-exec', ...args, ...Object.entries(flags).flatMap(([k, v]) => v === true ? [`--${k}`] : [`--${k}`, String(v)])]);
      } catch (error) {
        console.error('❌ Swarm execution error:', error.message);
        if (flags.verbose) {
          console.error(error.stack);
        }
        throw error;
      }
    },
    description: '🚀 Direct CLI interface for swarm execution without MCP dependency',
    usage: 'swarm-exec <command> [options]',
    examples: [
      'swarm-exec execute "Build a REST API with authentication"',
      'swarm-exec execute "Research AI trends" --strategy research --max-agents 8 --output-format json',
      'swarm-exec recover --list',
      'swarm-exec recover swarm_1697844234_abc123def',
      'swarm-exec status --all --format json',
      'swarm-exec status swarm_1697844234_abc123def'
    ],
    details: `
🚀 CLI SWARM EXECUTION INTERFACE FEATURES:
  • Direct CLI execution without MCP dependency
  • Support for up to 50 concurrent agents
  • Redis persistence for state management and recovery
  • Multiple output formats (json, text, stream)
  • Swarm recovery and status monitoring
  • Comprehensive error handling and validation

COMMANDS:
  execute <objective>    Execute a new swarm with the given objective
  recover [swarmId]      Recover and resume a swarm from Redis persistence
  status [swarmId]       Check status of active or completed swarms

STRATEGIES:
  auto                  Automatic strategy selection (default)
  development           Software development and coding
  research             Research and information gathering
  testing              Quality assurance and testing
  analysis             Data analysis and insights
  optimization         Performance optimization
  maintenance          System maintenance

COORDINATION MODES:
  centralized          Single coordinator (default)
  distributed          Multiple coordinators
  hierarchical         Tree structure coordination
  mesh                 Peer-to-peer coordination
  hybrid               Mixed coordination strategies

REDIS PERSISTENCE:
  • Automatic state saving with 24-hour TTL
  • Swarm recovery after interruption
  • Real-time status monitoring
  • Backup and restore capabilities
  • Automatic cleanup of expired states

OUTPUT FORMATS:
  text                 Human-readable formatted output (default)
  json                 Machine-readable JSON with metadata
  stream               Real-time streaming JSON for monitoring

EXAMPLE USAGE:
  # Basic execution
  swarm-exec execute "Create user authentication system"

  # Advanced configuration
  swarm-exec execute "Build microservices" \\
    --strategy development \\
    --max-agents 12 \\
    --mode hierarchical \\
    --output-format json \\
    --output-file results.json \\
    --persist --monitor

For comprehensive documentation, see: src/cli/docs/swarm-cli-guide.md`,
  });

  commandRegistry.set('hive-mind', {
    handler: hiveMindCommand,
    description: '🧠 Advanced Hive Mind swarm intelligence with collective decision-making',
    usage: 'hive-mind <subcommand> [options]',
    examples: [
      'hive-mind init                          # Initialize hive mind system',
      'hive-mind spawn "Build microservices"   # Create swarm with objective',
      'hive-mind wizard                        # Interactive setup wizard',
      'hive-mind status                        # View active swarms',
      'hive-mind consensus                     # View consensus decisions',
      'hive-mind metrics                       # Performance analytics',
    ],
    customHelp: true, // Use command's own help function
    details: `
Hive Mind System Features:
  • Queen-led coordination with specialized worker agents
  • Collective memory and knowledge sharing
  • Consensus building for critical decisions  
  • Auto-scaling based on workload
  • Parallel task execution with work stealing
  • Real-time monitoring and metrics
  • SQLite-backed persistence
  • MCP tool integration for 87+ operations

Queen Types:
  • Strategic - Long-term planning and optimization
  • Tactical - Task prioritization and rapid response
  • Adaptive - Learning and strategy evolution

Worker Types:
  • Researcher, Coder, Analyst, Tester
  • Architect, Reviewer, Optimizer, Documenter

Use 'hive-mind wizard' for interactive setup or 'hive-mind help' for full documentation.`,
  });

  commandRegistry.set('hive-mind-optimize', {
    handler: hiveMindOptimizeCommand,
    description: '🔧 Optimize hive mind database for better performance',
    usage: 'hive-mind-optimize [options]',
    examples: [
      'hive-mind-optimize                      # Interactive optimization wizard',
      'hive-mind-optimize --auto               # Auto-optimize with defaults',
      'hive-mind-optimize --report             # Generate optimization report',
      'hive-mind-optimize --clean-memory --memory-days 60',
      'hive-mind-optimize --auto --vacuum --archive-tasks',
    ],
    details: `
Hive Mind Database Optimization Features:
  • Safe, backward-compatible optimizations
  • Performance indexes for 50% faster queries
  • Memory cleanup and archiving
  • Task archival for space management
  • Behavioral pattern tracking
  • Database integrity checking
  
Optimization Levels:
  • v1.0 → v1.1: Basic performance indexes
  • v1.1 → v1.2: Advanced query optimization
  • v1.2 → v1.3: Performance tracking tables
  • v1.3 → v1.4: Memory optimization features
  • v1.4 → v1.5: Behavioral analysis tracking

Safety Features:
  • Automatic backups before major operations
  • All changes are backward-compatible
  • Existing data is always preserved
  • Rollback capability on errors`,
  });

  commandRegistry.set('swarm-metrics', {
    handler: async (args, flags) => {
      const subcommand = args[0];
      if (subcommand === 'fix') {
        return await fixTaskAttribution();
      } else {
        return await showUnifiedMetrics();
      }
    },
    description: 'Unified swarm metrics and task attribution diagnostics',
    usage: 'swarm-metrics [fix] [options]',
    examples: [
      'swarm-metrics                    # Show unified metrics from all swarm systems',
      'swarm-metrics fix                # Fix task attribution issues between systems',
    ],
    details: `
Swarm Metrics Integration Features:
  • Unified view of hive-mind and ruv-swarm metrics
  • Task attribution diagnosis and repair
  • Cross-system swarm performance comparison
  • Database integration status checking
  • Automatic sample task creation for empty swarms

This command helps resolve issues where:
  • Overall task statistics show correctly but per-swarm shows 0/0
  • Multiple swarm systems are not properly integrated
  • Task assignments are missing or incorrectly attributed

Use 'swarm-metrics fix' to automatically repair attribution issues.`,
  });

  commandRegistry.set('batch', {
    handler: batchManagerCommand,
    description: 'Batch operation management and configuration utilities',
    usage: 'batch <command> [options]',
    examples: [
      'batch create-config my-batch.json',
      'batch create-config --interactive',
      'batch validate-config my-batch.json',
      'batch estimate my-batch.json',
      'batch list-templates',
      'batch list-environments',
    ],
    details: `
Batch operations support:
  • Multiple project initialization with templates
  • Environment-specific configurations (dev, staging, prod)
  • Parallel processing with resource management
  • Progress tracking and detailed reporting
  • Configuration validation and estimation tools
  
Use with init command:
  claude-flow-novice init --batch-init project1,project2,project3
  claude-flow-novice init --config batch-config.json --parallel`,
  });

  commandRegistry.set('github', {
    handler: githubCommand,
    description: 'GitHub workflow automation with 6 specialized modes',
    usage: 'github <mode> <objective> [options]',
    examples: [
      'github pr-manager "create feature PR with automated testing"',
      'github gh-coordinator "setup CI/CD pipeline" --auto-approve',
      'github release-manager "prepare v2.0.0 release"',
      'github repo-architect "optimize repository structure"',
      'github issue-tracker "analyze project roadmap issues"',
      'github sync-coordinator "sync package versions across repos"',
    ],
    details: `
GitHub automation modes:
  • gh-coordinator: GitHub workflow orchestration and coordination
  • pr-manager: Pull request management with multi-reviewer coordination
  • issue-tracker: Issue management and project coordination
  • release-manager: Release coordination and deployment pipelines
  • repo-architect: Repository structure optimization
  • sync-coordinator: Multi-package synchronization and version alignment
  
Advanced features:
  • Multi-reviewer coordination with automated scheduling
  • Intelligent issue categorization and assignment
  • Automated testing integration and quality gates
  • Release pipeline orchestration with rollback capabilities`,
  });

  commandRegistry.set('training', {
    handler: trainingAction,
    description: 'Neural pattern learning and model updates',
    usage: 'training <command> [options]',
    examples: [
      'training neural-train --data recent --model task-predictor',
      'training pattern-learn --operation "file-creation" --outcome "success"',
      'training model-update --agent-type coordinator --operation-result "efficient"',
    ],
    details: `
Neural training commands:
  • neural-train: Train neural patterns from operations
  • pattern-learn: Learn from specific operation outcomes
  • model-update: Update agent models with new insights
  
Improves task selection accuracy, agent performance prediction, and coordination efficiency.`,
  });

  commandRegistry.set('analysis', {
    handler: analysisAction,
    description: 'Performance and usage analytics',
    usage: 'analysis <command> [options]',
    examples: [
      'analysis bottleneck-detect --scope system',
      'analysis performance-report --timeframe 7d --format detailed',
      'analysis token-usage --breakdown --cost-analysis',
    ],
    details: `
Analysis commands:
  • bottleneck-detect: Detect performance bottlenecks in the system
  • performance-report: Generate comprehensive performance reports
  • token-usage: Analyze token consumption and costs
  
Helps with performance optimization, cost management, and resource allocation.`,
  });

  commandRegistry.set('automation', {
    handler: automationAction,
    description: 'Intelligent agent and workflow management with MLE-STAR and Claude integration',
    usage: 'automation <command> [options]',
    examples: [
      'automation auto-agent --task-complexity enterprise --swarm-id swarm-123',
      'automation smart-spawn --requirement "web-development" --max-agents 8',
      'automation workflow-select --project-type api --priority speed',
      'automation run-workflow my-workflow.json --claude --non-interactive',
      'automation mle-star --dataset data/train.csv --target price --claude',
    ],
    details: `
Automation commands:
  • auto-agent: Automatically spawn optimal agents based on task complexity
  • smart-spawn: Intelligently spawn agents based on specific requirements
  • workflow-select: Select and configure optimal workflows for project types
  • run-workflow: Execute workflows from JSON/YAML files with Claude integration
  • mle-star: Run MLE-STAR Machine Learning Engineering workflow (flagship)
  
New features:
  • Claude CLI integration for actual execution
  • MLE-STAR methodology for ML engineering
  • Non-interactive mode for CI/CD integration
  • Comprehensive workflow templates
  
Provides optimal resource allocation, intelligent agent selection, and complete automation workflows.`,
  });

  commandRegistry.set('coordination', {
    handler: coordinationAction,
    description: 'Swarm and agent orchestration',
    usage: 'coordination <command> [options]',
    examples: [
      'coordination swarm-init --topology hierarchical --max-agents 8',
      'coordination agent-spawn --type developer --name "api-dev" --swarm-id swarm-123',
      'coordination task-orchestrate --task "Build REST API" --strategy parallel',
    ],
    details: `
Coordination commands:
  • swarm-init: Initialize swarm coordination infrastructure
  • agent-spawn: Spawn and coordinate new agents
  • task-orchestrate: Orchestrate task execution across agents
  
Enables intelligent task distribution, agent synchronization, and shared memory coordination.`,
  });

  commandRegistry.set('hook', {
    handler: async (args, flags) => {
      return hookCommand.action({ args, flags });
    },
    description: 'Execute hooks for agent coordination (ruv-swarm compatible)',
    usage: 'hook <subcommand> [options]',
    examples: [
      'hook pre-task --description "Build API"',
      'hook post-edit --file src/index.ts --memory-key "api/implementation"',
      'hook session-start',
      'hook session-end --export-metrics --generate-summary',
      'hook post-edit --file src/app.ts --format --tdd-mode',
    ],
    details: `
Hook Commands:
  • pre-task: Execute before task begins (preparation & setup)
  • post-task: Execute after task completion (analysis & cleanup)
  • pre-edit: Execute before file modifications (backup & validation)
  • post-edit: Execute after file modifications (validation & formatting)
  • pre-command: Execute before command execution (validation)
  • post-command: Execute after command execution (tracking)
  • session-start: Execute at session start (cleanup & soul loading)
  • session-end: Execute at session termination (cleanup & export)
  • session-restore: Restore previous session state
  • pre-search: Execute before search operations
  • notification: Send notifications
  • performance: Track performance metrics
  • memory-sync: Synchronize memory state
  • telemetry: Send telemetry data

Non-blocking behavior: All hooks exit with code 0 and log errors without blocking operations.`,
  });

  commandRegistry.set('hooks', {
    handler: hooksAction,
    description: 'Lifecycle event management (legacy)',
    usage: 'hooks <command> [options]',
    examples: [
      'hooks pre-task --description "Build API" --task-id task-123',
      'hooks post-task --task-id task-123 --analyze-performance --generate-insights',
      'hooks session-end --export-metrics --generate-summary',
    ],
    details: `
Hooks commands:
  • pre-task: Execute before task begins (preparation & setup)
  • post-task: Execute after task completion (analysis & cleanup)
  • pre-edit: Execute before file modifications (backup & validation)
  • post-edit: Execute after file modifications (tracking & coordination)
  • session-end: Execute at session termination (cleanup & export)

Enables automated preparation & cleanup, performance tracking, and coordination synchronization.`,
  });

  commandRegistry.set('hook-safety', {
    handler: hookSafetyCommand,
    description: '🚨 Critical hook safety system - Prevent infinite loops & financial damage',
    usage: 'hook-safety <command> [options]',
    examples: [
      'hook-safety validate                           # Check for dangerous hook configurations',
      'hook-safety validate --config ~/.claude/settings.json',
      'hook-safety status                             # View safety status and context',
      'hook-safety reset                              # Reset circuit breakers',
      'hook-safety safe-mode                          # Enable safe mode (skip all hooks)',
    ],
    details: `
🚨 CRITICAL: Stop hooks calling 'claude' commands create INFINITE LOOPS that can:
  • Bypass API rate limits
  • Cost thousands of dollars per day  
  • Make your system unresponsive

Hook Safety commands:
  • validate: Check Claude Code settings for dangerous patterns
  • status: Show current safety status and execution context
  • reset: Reset circuit breakers and execution counters  
  • safe-mode: Enable/disable safe mode (skips all hooks)

SAFE ALTERNATIVES:
  • Use PostToolUse hooks instead of Stop hooks
  • Implement flag-based update patterns
  • Use 'claude --skip-hooks' for manual updates
  • Create conditional execution scripts

For more information: https://github.com/ruvnet/claude-flow/issues/166`,
  });

  commandRegistry.set('migrate-hooks', migrateHooksCommandConfig);

  commandRegistry.set('fix-hook-variables', {
    handler: fixHookVariablesCommand,
    ...fixHookVariablesCommandConfig,
  });

  // Verification system commands
  commandRegistry.set('verify', {
    handler: async (args, flags) => {
      try {
        const { verificationCommand } = await import('./simple-commands/verification.js');
        return await verificationCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading verification module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '🔍 Verification and truth enforcement system',
    usage: 'verify <subcommand> [options]',
    examples: [
      'verify status                    # Show verification system status',
      'verify check --taskId task-123   # Run verification checks',
      'verify validate --taskId task-456 # Validate task results',
      'verify config                    # Manage verification config',
      'verify cleanup --force           # Clean up old verification data',
    ],
    details: `
Verification system commands:
  • status: Show current system status and health
  • check: Run verification checks on tasks
  • validate: Validate task completion and results
  • config: Manage verification configuration
  • cleanup: Clean up old verification data
  • pre-task: Execute pre-task verification
  • post-task: Execute post-task validation
  • integration: Run integration tests
  • truth: Execute truth telemetry checks
  • rollback: Trigger rollback if needed

Truth enforcement features:
  • 0.95 minimum truth threshold
  • Cross-agent integration testing
  • Automated rollback on failures
  • Cryptographic verification
  • Byzantine fault tolerance`,
  });

  commandRegistry.set('truth', {
    handler: async (args, flags) => {
      try {
        const { truthCommand } = await import('./simple-commands/verification.js');
        return await truthCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading verification module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '🎯 Truth telemetry and accuracy scoring',
    usage: 'truth [options]',
    examples: [
      'truth                            # Show current truth scores',
      'truth --taskId task-123          # Check truth for specific task',
      'truth --threshold 0.95           # Set minimum truth threshold',
      'truth --report                   # Generate truth report',
    ],
    details: `
Truth scoring system:
  • Real-time truth metrics collection
  • Agent performance scoring
  • System-wide truth accuracy tracking
  • Automated alerting for threshold violations
  • Dashboard data export functionality

Target metrics:
  • >95% truth accuracy rate
  • <10% human intervention rate
  • >90% integration success rate
  • <5% automated rollback frequency`,
  });

  commandRegistry.set('neural', {
    handler: neuralCommand,
    description: '🧠 Neural module commands for SAFLA self-learning systems',
    usage: 'neural <command> [options]',
    examples: [
      'neural init                      # Initialize neural module',
      'neural init --force              # Force overwrite existing',
      'neural init --target ./agents    # Custom location',
    ],
    details: `
Neural Module Features:
  • Self-Aware Feedback Loop Algorithm (SAFLA)
  • 4-tier memory system (Vector, Episodic, Semantic, Working)
  • 172,000+ ops/sec processing with WASM optimization
  • 60% memory compression while maintaining recall
  • Cross-session learning and persistence
  • Distributed neural training with MCP integration`,
  });

  commandRegistry.set('goal', {
    handler: goalCommand,
    description: '🎯 Goal module commands for GOAP intelligent planning',
    usage: 'goal <command> [options]',
    examples: [
      'goal init                        # Initialize goal module',
      'goal init --force                # Force overwrite existing',
      'goal init --target ./agents      # Custom location',
    ],
    details: `
Goal Module Features:
  • Goal-Oriented Action Planning (GOAP) algorithm
  • A* pathfinding for optimal plan generation
  • OODA loop execution monitoring
  • Adaptive replanning on failures
  • Mixed LLM + code execution
  • Cost-optimized action sequences`,
  });

  commandRegistry.set('pair', {
    handler: async (args, flags) => {
      try {
        const pairCommand = (await import('./simple-commands/pair.js')).default;
        return await pairCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading pair module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '👥 Interactive pair programming with AI assistance',
    usage: 'pair [options]',
    examples: [
      'pair --start                     # Start pair programming session',
      'pair --start --mode driver       # You write, AI assists',
      'pair --start --verify --test     # Enable verification and testing',
      'pair --status                    # Show session status',
      'pair --end                       # End current session',
    ],
    details: `
Pair programming features:
  • Three modes: driver, navigator, switch
  • Real-time code assistance
  • Optional verification and testing
  • Session persistence
  • Background execution support`,
  });

  commandRegistry.set('verify-train', {
    handler: async (args, flags) => {
      try {
        const { verificationTrainingCommand } = await import(
          './simple-commands/verification-training-integration.js'
        );
        return await verificationTrainingCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading verification-training module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '🧠 Verification-Training integration for continuous improvement',
    usage: 'verify-train <command> [options]',
    examples: [
      'verify-train status              # Show training status',
      'verify-train feed                # Feed verification data to training',
      'verify-train predict coder       # Predict verification outcome',
      'verify-train recommend           # Get agent recommendations',
      'verify-train train               # Trigger neural training',
    ],
    details: `
Verification-Training Integration:
  • Feeds verification results to training system
  • Learns from agent performance over time
  • Predicts verification outcomes
  • Recommends best agents for tasks
  • Improves reliability through continuous learning`,
  });

  commandRegistry.set('train-pipeline', {
    handler: async (args, flags) => {
      try {
        // Always use real execution - no more simulation
        const { trainingPipelineCommand } = await import('./simple-commands/training-pipeline.js');
        return await trainingPipelineCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading training-pipeline module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '🚀 Real training pipeline with actual code execution and learning',
    usage: 'train-pipeline <command> [options]',
    examples: [
      'train-pipeline run               # Run training with real code',
      'train-pipeline run --complexity hard --iterations 5',
      'train-pipeline generate          # Generate real training tasks',
      'train-pipeline validate          # Validate current performance',
      'train-pipeline status            # Show pipeline status with real metrics',
    ],
    details: `
Real Training Pipeline Features:
  • Creates actual code files and tests
  • Runs real npm test commands
  • Learns from actual test results
  • Validates improvements with real metrics
  • Applies learned optimizations to production
  
Pipeline Stages:
  1. Generate real code tasks (easy/medium/hard)
  2. Execute with different strategies using npm
  3. Learn from real test results
  4. Validate actual improvements
  5. Apply to production configuration
  
Options:
  --complexity <level> Task complexity (easy/medium/hard)
  --iterations <n>     Number of training iterations`,
  });

  commandRegistry.set('stream-chain', {
    handler: async (args, flags) => {
      try {
        const { streamChainCommand } = await import('./simple-commands/stream-chain.js');
        return await streamChainCommand(args, flags);
      } catch (error) {
        console.error('❌ Error loading stream-chain module:', error.message);
        console.log('Error details:', error);
      }
    },
    description: '🔗 Connect multiple Claude instances via stream-json for chained workflows',
    usage: 'stream-chain <subcommand> [options]',
    examples: [
      'stream-chain run "analyze" "design" "implement"  # Custom chain',
      'stream-chain demo                                 # Run demo chain',
      'stream-chain pipeline analysis                    # Run analysis pipeline',
      'stream-chain test                                 # Test stream connection',
      'stream-chain help                                 # Show detailed help',
    ],
    details: `
📚 SUBCOMMANDS
    run <p1> <p2> [...]  Execute custom chain (min 2 prompts)
    demo                 Run 3-step demo chain
    pipeline <type>      Run predefined pipeline (analysis/refactor/test/optimize)
    test                 Test stream connection
    help                 Show comprehensive documentation

⚙️  OPTIONS
    --verbose            Show detailed execution info
    --timeout <seconds>  Timeout per step (default: 30)
    --debug              Enable debug mode

🔄 STREAM CHAINING
    Chains multiple Claude Code calls with context preservation:
    • Step 1 outputs stream-json → Step 2 receives context → Step 3...
    • 100% context preservation between steps
    • Real execution with Claude Code (not simulated)

🚀 PIPELINES
    analysis  - Analyze → Identify issues → Generate report
    refactor  - Find opportunities → Create plan → Apply changes
    test      - Analyze coverage → Design cases → Generate tests
    optimize  - Profile code → Find bottlenecks → Apply optimizations

⚡ PERFORMANCE
    • Latency: ~10-30s per step
    • Context: Full preservation
    • Streaming: No intermediate files

📖 For full documentation: stream-chain help`,
  });

  commandRegistry.set('personalize', {
    handler: personalizationCommand,
    description: '🎯 Unified personalization system with AI-powered workflow optimization',
    usage: 'personalize <subcommand> [options]',
    examples: [
      'personalize setup                             # Run comprehensive setup wizard',
      'personalize status                            # Show personalization status',
      'personalize optimize                          # Get optimization suggestions',
      'personalize analytics                         # Show usage analytics and insights',
      'personalize resource assign coder             # Resource delegation commands',
      'personalize dashboard                         # Open interactive dashboard',
      'personalize export settings.json              # Export personalization data',
    ],
    details: `
🎯 UNIFIED PERSONALIZATION SYSTEM
  Comprehensive personalization platform that adapts Claude Flow Novice to your
  specific workflow patterns, experience level, and project requirements.

🧙‍♂️ SETUP WIZARD
  Interactive configuration wizard that:
  • Assesses your experience level and project focus
  • Configures communication style and verbosity preferences
  • Sets up workflow automation and agent coordination
  • Enables analytics and performance tracking
  • Customizes resource allocation patterns

📊 ANALYTICS & INSIGHTS
  • Real-time usage analytics and performance metrics
  • Personalized workflow optimization suggestions
  • Agent performance tracking and recommendations
  • Pattern recognition for improved efficiency
  • Interactive dashboard with live monitoring

⚡ RESOURCE DELEGATION
  • Dynamic agent assignment based on task complexity
  • Intelligent resource allocation optimization
  • Custom delegation rules and priority management
  • Performance-based agent selection

🔧 WORKFLOW OPTIMIZATION
  • AI-powered suggestion engine for workflow improvements
  • Automated optimization application with approval
  • Performance impact analysis and tracking
  • Cross-session learning and adaptation

🎛️ CONTENT FILTERING
  • Personalized content prioritization and filtering
  • Context-aware information presentation
  • Adaptive verbosity based on user expertise
  • Smart noise reduction for focused workflows

💾 DATA MANAGEMENT
  • Export/import personalization settings
  • Cross-session persistence and learning
  • Privacy-first analytics with user control
  • Backup and restore capabilities`,
  });

  commandRegistry.set('preferences', {
    handler: preferencesCommand,
    description: '⚙️ User preference management and configuration wizard',
    usage: 'preferences <subcommand> [options]',
    examples: [
      'preferences setup                              # Run interactive preference wizard',
      'preferences show                               # Display current preferences',
      'preferences set documentation.verbosity detailed',
      'preferences set workflow.concurrency 4',
      'preferences get feedback.tone',
      'preferences suggest                            # Get improvement suggestions',
      'preferences export my-settings.json           # Export preferences',
      'preferences reset --force                      # Reset to defaults',
    ],
    details: `
Preference Management Features:
  • Interactive setup wizard for new users
  • Project-specific and global preference scopes
  • Smart defaults based on experience level and project type
  • Preference validation and suggestions
  • Import/export capabilities
  • Context-aware preference adaptation

🧙‍♂️ SETUP WIZARD
  Collects user preferences through interactive prompts:
  • Experience level and development background
  • Documentation verbosity and explanation preferences
  • Communication tone and error handling style
  • Workflow preferences and agent coordination
  • Advanced features and integrations

⚙️ PREFERENCE CATEGORIES
  experience.*     User experience level and background
  documentation.*  Documentation verbosity and style preferences
  feedback.*       Communication tone and error handling
  workflow.*       Agent coordination and automation settings
  advanced.*       Advanced features and neural learning
  project.*        Auto-detected project-specific settings

🔧 COMMANDS
  setup           Run interactive preference wizard
  show [scope]    Display current preferences (all/global/project)
  set <key> <val> Set preference value with dot notation
  get <key>       Get specific preference value
  reset [scope]   Reset preferences to defaults
  validate        Validate current preference values
  export [file]   Export preferences to JSON file
  import <file>   Import preferences from file
  suggest         Get optimization suggestions
  list            Show all available preference keys

🎯 CONTEXTUAL ADAPTATION
  Preferences adapt based on:
  • Task complexity (simple tasks use minimal verbosity)
  • System resources (limits agent concurrency)
  • User experience level (adjusts guidance and explanations)`,
  });

  commandRegistry.set('hive', {
    handler: async (args, flags) => {
      try {
        // Try to load the hive command module
        const { hiveAction } = await import('./commands/hive.js');
        return hiveAction({ args, flags, command: 'hive' });
      } catch (error) {
        // Fallback to simple implementation if module not found
        console.log('🐝 Hive Mind - Advanced Multi-Agent Coordination');
        console.log('');
        console.log('The Hive Mind system provides:');
        console.log('  • Consensus-based decision making');
        console.log('  • Distributed task orchestration');
        console.log('  • Quality-driven execution');
        console.log('  • Real-time swarm monitoring');
        console.log('');
        console.log('Usage: hive <objective> [options]');
        console.log('');
        console.log('For full functionality, ensure the hive module is properly built.');
      }
    },
    description: 'Hive Mind - Advanced multi-agent swarm with consensus',
    usage: 'hive <objective> [options]',
    examples: [
      'hive "Build microservices architecture"',
      'hive "Optimize database performance" --consensus unanimous',
      'hive "Develop ML pipeline" --topology mesh --monitor',
      'hive "Create REST API" --sparc --max-agents 8',
      'hive "Research cloud patterns" --background --quality-threshold 0.9',
    ],
    details: `
Hive Mind features:
  • 👑 Queen-led orchestration with specialized agents
  • 🗳️ Consensus mechanisms (quorum, unanimous, weighted, leader)
  • 🏗️ Multiple topologies (hierarchical, mesh, ring, star)
  • 📊 Real-time monitoring dashboard
  • 🧪 SPARC methodology integration
  • 💾 Distributed memory and knowledge sharing
  
Agent types:
  • Queen: Orchestrator and decision maker
  • Architect: System design and planning  
  • Worker: Implementation and execution
  • Scout: Research and exploration
  • Guardian: Quality and validation
  
Options:
  --topology <type>         Swarm topology (default: hierarchical)
  --consensus <type>        Decision mechanism (default: quorum)
  --max-agents <n>          Maximum agents (default: 8)
  --quality-threshold <n>   Min quality 0-1 (default: 0.8)
  --sparc                   Use SPARC methodology
  --monitor                 Real-time monitoring
  --background              Run in background`,
  });

  // Temporarily commented out for Node.js compatibility
  /*
  commandRegistry.set('ruv-swarm', {
    handler: ruvSwarmAction,
    description: 'Advanced AI swarm coordination with neural capabilities',
    usage: 'ruv-swarm <command> [options]',
    examples: [
      'ruv-swarm init --topology mesh --max-agents 8',
      'ruv-swarm spawn researcher --name "AI Researcher"',
      'ruv-swarm orchestrate "Build a REST API"',
      'ruv-swarm neural train --iterations 20',
      'ruv-swarm benchmark --type swarm',
      'ruv-swarm config show',
      'ruv-swarm status --verbose'
    ],
    details: `
Advanced swarm coordination features:
  • 84.8% SWE-Bench solve rate
  • 32.3% token reduction through coordination
  • 2.8-4.4x speed improvement via parallel execution
  • 27+ neural models for cognitive approaches
  • Persistent memory across sessions
  • Automatic topology optimization
  
Commands:
  init        - Initialize swarm with specified topology
  status      - Get current swarm status and metrics
  spawn       - Spawn specialized agents (researcher, coder, analyst, etc.)
  orchestrate - Coordinate complex tasks across agents
  neural      - Neural pattern training and management
  benchmark   - Performance testing and optimization
  config      - Configuration management
  memory      - Memory usage and coordination data`
  });
  */

  // Additional ruv-swarm coordination commands - temporarily commented out
  /*
  commandRegistry.set('swarm-init', {
    handler: async (args, flags) => {
      const { ruvSwarmAction } = await import('./commands/ruv-swarm.js');
      return ruvSwarmAction({ args: ['init', ...args], flags });
    },
    description: 'Quick swarm initialization with topology selection',
    usage: 'swarm-init [--topology <type>] [--max-agents <n>] [--strategy <type>]',
    examples: [
      'swarm-init --topology mesh --max-agents 8',
      'swarm-init --topology hierarchical --strategy specialized',
      'swarm-init --topology star --max-agents 5 --strategy balanced'
    ]
  });

  commandRegistry.set('neural-spawn', {
    handler: async (args, flags) => {
      const { ruvSwarmAction } = await import('./commands/ruv-swarm.js');
      return ruvSwarmAction({ args: ['spawn', ...args], flags });
    },
    description: 'Spawn neural agents with cognitive capabilities',
    usage: 'neural-spawn <type> [--name <name>] [--capabilities <list>]',
    examples: [
      'neural-spawn researcher --name "Data Analyst"',
      'neural-spawn coder --capabilities "typescript,react,api"',
      'neural-spawn coordinator --name "Project Manager"'
    ]
  });

  commandRegistry.set('memory-coordinate', {
    handler: async (args, flags) => {
      const { ruvSwarmAction } = await import('./commands/ruv-swarm.js');
      return ruvSwarmAction({ args: ['memory', ...args], flags });
    },
    description: 'Coordinate memory across swarm agents',
    usage: 'memory-coordinate [--detail <level>] [--sync] [--compress]',
    examples: [
      'memory-coordinate --detail summary',
      'memory-coordinate --detail detailed --sync',
      'memory-coordinate --compress --sync'
    ]
  });

  commandRegistry.set('config-integration', {
    handler: configIntegrationAction,
    description: 'Enhanced configuration management with ruv-swarm integration',
    usage: 'config-integration <command> [options]',
    examples: [
      'config-integration setup --enable-ruv-swarm',
      'config-integration preset development',
      'config-integration sync --force',
      'config-integration status --verbose',
      'config-integration export my-config.json',
      'config-integration validate --fix'
    ],
    details: `
Advanced configuration management features:
  • Unified configuration across Claude-Flow and ruv-swarm
  • Configuration presets for different environments
  • Automatic synchronization between config systems
  • Import/export capabilities with validation
  • Real-time status monitoring and validation
  
Presets:
  development  - Hierarchical topology, specialized strategy, 8 agents
  research     - Mesh topology, adaptive strategy, 12 agents  
  production   - Star topology, balanced strategy, 6 agents
  
Commands:
  setup        - Initialize ruv-swarm integration
  sync         - Synchronize configurations
  status       - Show integration status
  validate     - Validate all configurations
  preset       - Apply configuration preset
  export       - Export unified configuration
  import       - Import and apply configuration`
  });
  */

  // Custom Framework Validation System
  commandRegistry.set('create-template', {
    handler: async (args, flags) => {
      try {
        const { program } = await import('./commands/create-template.js');
        program.parse(['node', 'create-template', ...args, ...Object.entries(flags).flatMap(([k, v]) => v === true ? [`--${k}`] : [`--${k}`, String(v)])]);
      } catch (error) {
        console.error('❌ Template creation error:', error.message);
        if (flags.verbose) {
          console.error(error.stack);
        }
        throw error;
      }
    },
    description: '🚀 Generate ready-to-use project templates for common use cases',
    usage: 'create-template <command> [options]',
    examples: [
      'create-template wizard                                    # Interactive template creation',
      'create-template generate basic-swarm -n my-project       # Generate basic swarm template',
      'create-template generate fleet-manager -n my-fleet       # Generate fleet manager template',
      'create-template generate event-bus -n my-eventbus        # Generate event bus template',
      'create-template generate custom-agent -n my-agent        # Generate custom agent template',
      'create-template list                                     # List available templates',
    ],
    details: `
🚀 READY-TO-USE TEMPLATES:

1. basic-swarm - Basic Swarm Coordination
   • Mesh topology for 2-7 agents
   • Redis-backed persistence and recovery
   • Working examples with comprehensive tests
   • Copy-paste ready code snippets

2. fleet-manager - Enterprise Fleet Management
   • Auto-scaling for 1000+ agents
   • Multi-region deployment support
   • Efficiency optimization (target 40%+)
   • Real-time monitoring dashboard

3. event-bus - High-Performance Event Bus
   • 10,000+ events/sec throughput
   • Pub/sub messaging patterns
   • Worker thread optimization
   • Priority-based routing

4. custom-agent - Custom Agent Development
   • Agent scaffolding with TypeScript
   • Integration examples
   • Comprehensive testing setup
   • Type-safe development

COMMANDS:
  generate <type>    Generate specific template type
  list              List all available templates
  wizard            Interactive template creation wizard

TEMPLATE FEATURES:
  • Working out-of-the-box with zero configuration
  • Clear inline documentation and examples
  • Comprehensive test suites included
  • TypeScript support with strict typing
  • Production-ready structure
  • Copy-paste ready code snippets

For detailed documentation, see: docs/QUICK_START.md`,
  });

  commandRegistry.set('validate', {
    handler: async (args, flags) => {
      const [subcommand, ...subArgs] = args;

      if (subcommand === 'framework') {
        return handleFrameworkValidationCommand(subArgs, flags);
      } else {
        // Handle other validation commands or show help
        console.log(`
🔍 Validation Commands

USAGE:
  claude-flow-novice validate <type> [options]

TYPES:
  framework <command>    Custom framework validation and management

FRAMEWORK COMMANDS:
  add <file>            Add and validate a custom framework
  test <id>             Test a framework with mock completion
  list                  List all custom frameworks
  remove <id>           Remove a custom framework
  export <id> [file]    Export framework to file
  wizard                Interactive framework creation wizard
  validate <completion> <id>  Validate completion with framework

EXAMPLES:
  claude-flow-novice validate framework add my-framework.json
  claude-flow-novice validate framework wizard
  claude-flow-novice validate framework test my-custom-framework
  claude-flow-novice validate framework validate completion.json my-framework
`);
        return { success: true, help: true };
      }
    },
    description: '🔍 Validation system for custom frameworks and completions',
    usage: 'validate framework <command> [options]',
    examples: [
      'validate framework add my-framework.json       # Add custom framework',
      'validate framework wizard                       # Interactive framework creation',
      'validate framework test my-custom-framework     # Test framework',
      'validate framework list                         # List all frameworks',
      'validate framework validate completion.json my-framework # Validate completion',
    ],
    details: `
Custom Framework Validation System:

🚀 CORE FEATURES:
  • Custom truth component weights and thresholds
  • Framework-specific validation rules with safe execution
  • Quality gates for completion metrics
  • Security enforcement with malicious code detection
  • Byzantine consensus for framework approval
  • Framework inheritance and composition support

🔒 SECURITY FEATURES:
  • Sandboxed execution of validation rules
  • Code injection detection and prevention
  • Byzantine consensus validation for malicious behavior
  • Cryptographic signing of approved frameworks
  • Security pattern validation and enforcement

📊 TRUTH SCORING INTEGRATION:
  • Integrates with existing TruthScorer (745 lines)
  • Custom component weights for domain-specific validation
  • Framework-specific truth thresholds
  • Real-time validation with performance monitoring

🧙 INTERACTIVE WIZARD:
  • Step-by-step framework creation process
  • Built-in validation and security checks
  • Auto-generation of common validation patterns
  • Export and import framework definitions

Use 'claude-flow-novice validate framework --help' for detailed command information.`,
  });
}

// Register a new command
export function registerCommand(name, command) {
  if (commandRegistry.has(name)) {
    console.warn(`Command '${name}' already exists and will be overwritten`);
  }

  commandRegistry.set(name, {
    handler: command.handler,
    description: command.description || 'No description available',
    usage: command.usage || `${name} [options]`,
    examples: command.examples || [],
    hidden: command.hidden || false,
  });
}

// Get command handler
export function getCommand(name) {
  return commandRegistry.get(name);
}

// List all registered commands
export function listCommands(includeHidden = false) {
  const commands = [];
  for (const [name, command] of commandRegistry.entries()) {
    if (includeHidden || !command.hidden) {
      commands.push({
        name,
        ...command,
      });
    }
  }
  return commands.sort((a, b) => a.name.localeCompare(b.name));
}

// Check if command exists
export function hasCommand(name) {
  return commandRegistry.has(name);
}

// Execute a command
export async function executeCommand(name, subArgs, flags) {
  const command = commandRegistry.get(name);
  if (!command) {
    throw new Error(`Unknown command: ${name}`);
  }

  try {
    // Track command execution for performance metrics
    await trackCommandExecution(name, command.handler, subArgs, flags);
  } catch (err) {
    throw new Error(`Command '${name}' failed: ${err.message}`);
  }
}

// Helper to show command help
export function showCommandHelp(name) {
  const command = commandRegistry.get(name);
  if (!command) {
    console.log(
      HelpFormatter.formatError(
        `Unknown command: ${name}`,
        'claude-flow',
        'claude-flow-novice <command> [options]',
      ),
    );
    return;
  }

  // If command has custom help, call it with help flag
  if (command.customHelp) {
    command.handler(['--help'], { help: true });
    return;
  }

  // Convert command info to standardized format
  const helpInfo = {
    name: `claude-flow-novice ${name}`,
    description: HelpFormatter.stripFormatting(command.description),
    usage: `claude-flow-novice ${command.usage}`,
    details: command.details, // Pass through the details section
  };

  // Parse examples
  if (command.examples && command.examples.length > 0) {
    helpInfo.examples = command.examples.map((ex) => {
      if (ex.startsWith('npx')) {
        return ex;
      }
      return `claude-flow-novice ${ex}`;
    });
  }

  // Parse options from details if available
  if (command.details) {
    const optionsMatch = command.details.match(/Options:([\s\S]*?)(?=\n\n|$)/);
    if (optionsMatch) {
      const optionsText = optionsMatch[1];
      const options = [];
      const optionLines = optionsText.split('\n').filter((line) => line.trim());

      for (const line of optionLines) {
        const match = line.match(/^\s*(--.+?)\s{2,}(.+)$/);
        if (match) {
          let [_, flags, description] = match;
          // Check for default value in description
          const defaultMatch = description.match(/\(default: (.+?)\)/);
          const option = {
            flags: flags.trim(),
            description: description.replace(/\(default: .+?\)/, '').trim(),
          };
          if (defaultMatch) {
            option.defaultValue = defaultMatch[1];
          }
          options.push(option);
        }
      }

      if (options.length > 0) {
        helpInfo.options = options;
      }
    }
  }

  console.log(HelpFormatter.formatHelp(helpInfo));
}

// Helper to show all commands
export function showAllCommands() {
  const commands = listCommands();

  console.log('Available commands:');
  console.log();

  for (const command of commands) {
    console.log(`  ${command.name.padEnd(12)} ${command.description}`);
  }

  console.log();
  console.log('Use "claude-flow-novice help <command>" for detailed usage information');
}

// Initialize the command registry
registerCoreCommands();

// Initialize performance tracking
initializePerformanceTracking().catch((err) => {
  // Performance tracking is optional, don't fail if it errors
  console.error('Failed to initialize performance tracking:', err.message);
});
